# LocationLab 0.4 (Android)

App indipendente di posizione GPS simulata, senza pubblicita o SDK di tracciamento.

## Migliorie v0.4
- Pan continuo anche quando arrivano nuove tile: mostra l’ultima vista gia disegnata come sfondo georiferito fino all’aggiornamento.
- Fallback da tile gia in cache fino a cinque livelli, senza prefetch non autorizzato.
- Caricamento tile visibili prioritarizzato, richieste obsolete in coda eliminate; massimo due connessioni attive.
- Cache RAM ampliata, cache su disco con riuso anche se scaduta in attesa della verifica HTTP.
- Pan continuo con un dito dopo il pinch-to-zoom.

## Modifiche v0.3
- `ACCESS_MOCK_LOCATION` nel manifest: l'app e candidabile nel selettore posizione fittizia delle Opzioni sviluppatore.
- Gestione degli inset delle barre di sistema per Android 15/16: nessun comando sotto la navigation bar.
- Interfaccia dark, barra ricerca e pannello compatto con un solo pulsante principale.
- Mappa con pinch zoom continuo, pan, fling e fallback da tile parent; stile mappa scuro/chiaro dal menu.
- Nessuna associazione PDF/P7M nel manifest.

## Installazione
Compilare con GitHub Actions (`:app:assembleDebug`) e installare la APK generata.
Per attivare: Opzioni sviluppatore > App per posizione fittizia > LocationLab.
Per aggiornare: installare sopra la v0.2 (stesso applicationId e firma debug coerente sullo stesso runner non garantita; in caso di conflitto disinstallare la precedente, dopo aver valutato che i dati locali verranno eliminati).

## Licenza mappe
© OpenStreetMap contributors. Le tile vengono richieste solo per la vista corrente, con cache di almeno 7 giorni e User-Agent dedicato.
