# LocationLab 2.0 — Android GPS Simulator

App Android indipendente, senza SDK pubblicitari, senza collegamenti a PDF/P7M e senza permessi per i file del telefono. Java, API Android 26–35 (Android 8–16, da verificare sui diversi produttori).

## Funzioni

- Mappa OpenStreetMap chiara/scura con zoom continuo, scorrimento fluido e cache. © OpenStreetMap contributors.
- Selezione punto toccando la mappa, ricerca via geocoder, inserimento coordinate.
- Simulazione GPS statica tramite opzioni sviluppatore > App per posizione fittizia.
- **Percorso progressivo**: tocca «Percorso», scegli l'attuale pin come partenza, poi tocca l'arrivo e specifica la velocità. L'animazione segue una **traiettoria geografica diretta (ortodromia), NON una strada**, quindi non naviga per vie e autostrade. Quando giunge all'arrivo, la simulazione termina automaticamente.
- **Parametri GPS** in menu ⋮: altitudine (metri/piedi), precisione dichiarata in metri, velocità statica (km/h/mph), oscillazione casuale massima (raggio in metri, 0 = spenta).
- **Notifica persistente** durante la simulazione con Pausa / Riprendi / Termina. In pausa i provider di posizione simulata vengono disabilitati e possono tornare a funzionare quelli reali. La ripresa è un comando esplicito dell'utente.
- **Ultima posizione** ripristinata all'apertura, ma nessun avvio automatico GPS.
- **Preferiti** con nome, categoria, descrizione e possibilità di modifica; cronologia; importazione ed esportazione JSON (i backup della versione 1.0 sono compatibili).
- Apertura posizione selezionata in Google Maps; ricentramento GPS reale a simulazione disattivata.

## Uso

1. Installa il file APK debug dall'artefatto GitHub Actions `LocationLab-2.0-APK`.
2. Vai in *Impostazioni > Opzioni sviluppatore > App per posizione fittizia* e scegli LocationLab.
3. Concedi la localizzazione precisa, e le notifiche se vuoi i comandi dalla notifica.
4. Tocca un punto e avvia la simulazione. Per un percorso usa «Percorso» e scegli il punto finale.
5. Per salvare preferiti e note, usa ☆ Salva; per aggiornare un elemento usa *Preferiti > Modifica*. Backup dal menu ⋮.

### Aggiornamento dalla 1.0

Il package rimane `it.locationlab.app`. Le compilazioni debug GitHub potrebbero usare firme differenti: in tal caso esporta prima i preferiti, disinstalla la versione precedente e installa la nuova, poi importa il JSON. Non disinstallare la versione precedente prima di aver effettuato il backup.

### Limitazioni

La simulazione di percorso non fa routing stradale, né aggira restrizioni delle app di terze parti. L'altitudine e la precisione impostate sono valori artificiali. La durata dell'esecuzione in background dipende dalle restrizioni del produttore e dal sistema operativo. La mappa richiede la rete per le tile mai viste; non viene scaricata un'area offline.
