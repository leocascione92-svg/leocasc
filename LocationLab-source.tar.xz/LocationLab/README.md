# LocationLab 1.0

GPS Emulator indipendente, senza pubblicità, tema scuro, mappe OpenStreetMap e selezione posizione simulata dalle Opzioni sviluppatore.

## Funzionalità finali
- Cerca indirizzi, seleziona coordinate e preferiti.
- Apri coordinate selezionate in Google Maps (tasto Maps).
- Esporta e importa preferiti come backup JSON dal menu ⋮: non usa permessi di memoria. L’importazione aggiunge i preferiti senza cancellare quelli già presenti.
- Pulsante ◎ sulla mappa: ritorna alla posizione GPS reale del telefono, previa autorizzazione della posizione precisa. Se la simulazione è attiva bisogna prima fermarla.
- Posizione fittizia tramite Android Developer Options, nessuna richiesta di root.

**Nota:** gli APK debug prodotti da diverse esecuzioni GitHub Actions possono usare firme differenti. Se Android rifiuta l’aggiornamento, può essere necessario disinstallare la versione precedente, perdendo i dati locali di quell’installazione.

© OpenStreetMap contributors.
