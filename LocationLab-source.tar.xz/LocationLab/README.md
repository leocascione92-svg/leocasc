# LocationLab 3.0 — GPS simulato con routing reale

**App Android indipendente, senza pubblicità o SDK di tracciamento.**

## Modalità

- **Posizione fissa**: scegli un punto sulla mappa. Il pulsante principale mostra "Avvia posizione fissa".
- **Percorso**: scegli la partenza, il mezzo e l'arrivo sulla mappa. Il pulsante principale mostra "Avvia percorso" quando la modalità percorso è selezionata.
  - **A piedi**: itinerario sui camminamenti e sentieri attraverso il servizio OSRM di FOSSGIS.
  - **Auto**: itinerario sulla rete stradale attraverso OSRM di FOSSGIS.
  - **Aereo**: arco geografico ortodromico, senza strade, con velocità personalizzabile.

Le rotte auto/piedi vengono richieste via HTTPS a `routing.openstreetmap.de` soltanto su esplicita azione dell'utente; **le coordinate di partenza e destinazione vengono inviate al server di FOSSGIS**. Gli itinerari vengono salvati localmente, e possono essere riutilizzati senza una nuova richiesta. Il servizio pubblico potrebbe non essere disponibile o rifiutare il percorso: in tal caso l'app segnala l'errore e non sostituisce il percorso stradale con una semplice retta. Le richieste vengono limitate a massimo una ogni 1,1 secondi e includono uno user-agent identificabile. Nessun download massivo delle mappe.

Il GPS simulato segue la geometria del percorso, riportando latitudine/longitudine, direzione (bearing) e velocità. Il movimento si aggiorna a intervalli di circa un secondo; è una simulazione a velocità costante e **non implementa la navigazione con le condizioni reali del traffico, i semafori o gli orari aerei**.

## Altre funzioni mantenute

- Tema nero e mappa OpenStreetMap fluida.
- Altitudine, precisione GPS, velocità e oscillazione configurabile (oscillazione disabilitata automaticamente lungo i percorsi per restare sulla rete stradale).
- Preferiti nominabili, categorie e note, backup/importazione JSON.
- Coordinate manuali, cronologia e apertura in Maps.
- Posizione reale del telefono; stop/ripresa dalla notifica.
- Ultima posizione selezionata ripristinata, senza avvio automatico della simulazione.
- Unità km/h o mph, metri o piedi.
- Nessuna associazione file PDF/P7M.

## Installazione

1. Compila il progetto usando `.github/workflows/locationlab-apk.yml`, oppure scarica l'artefatto `LocationLab-3.0-APK` della compilazione riuscita da GitHub Actions.
2. Seleziona **LocationLab** in **Impostazioni > Opzioni sviluppatore > App per posizione fittizia**.
3. Prima di sostituire la vecchia versione, esporta i preferiti in JSON. Le build debug create su runner GitHub diversi possono usare firme incompatibili tra loro: potrebbe essere necessaria una disinstallazione che elimina i dati locali.

È una versione di prova installabile; i comportamenti specifici del dispositivo e la disponibilità del routing online devono essere verificati sul telefono.

© OpenStreetMap contributors; routing © FOSSGIS. [Informativa sul servizio di routing](https://routing.openstreetmap.de/about.html).
