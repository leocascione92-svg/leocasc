package it.locationlab.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.*;
import android.os.*;
import java.util.*;

/** Servizio GPS di test avviato solo da un comando esplicito dell'utente. */
public final class MockLocationService extends Service {
    public static final String ACTION_START = "it.locationlab.app.START";
    public static final String ACTION_STOP = "it.locationlab.app.STOP";
    public static final String ACTION_PAUSE = "it.locationlab.app.PAUSE";
    public static final String ACTION_RESUME = "it.locationlab.app.RESUME";
    public static final String EXTRA_LAT = "lat", EXTRA_LON = "lon";
    public static final String EXTRA_ALTITUDE = "altitude", EXTRA_ACCURACY = "accuracy";
    public static final String EXTRA_SPEED_MPS = "speed", EXTRA_JITTER = "jitter";
    public static final String EXTRA_ROUTE = "route", EXTRA_END_LAT = "end_lat", EXTRA_END_LON = "end_lon";
    private static final int NOTIFICATION_ID = 501;
    private static final String CHANNEL_ID = "mock_gps";
    private static final double EARTH_METERS = 6371000d;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Set<String> installedProviders = new HashSet<>();
    private final Random random = new Random();
    private LocationManager manager;
    private boolean active, paused, routeMode;
    private double startLat, startLon, endLat, endLon;
    private double altitudeMeters, accuracyMeters, speedMetersPerSec, jitterMeters;
    private double routeDistanceMeters, progressedMeters, jitterX, jitterY;
    private double latitude, longitude;
    private long lastTickRealtime, lastNoticeRealtime;
    private float bearing;

    @Override public void onCreate() {
        super.onCreate();
        manager = (LocationManager)getSystemService(LOCATION_SERVICE);
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Posizione simulata", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Pausa, riprendi o termina la simulazione GPS");
            nm.createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) { finishSimulation(false); return START_NOT_STICKY; }
        if (ACTION_PAUSE.equals(action)) {
            if (active && !paused) pauseSimulation();
            return START_NOT_STICKY;
        }
        if (ACTION_RESUME.equals(action)) {
            if (active && paused) resumeSimulation();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action)) return START_NOT_STICKY;
        startLat = intent.getDoubleExtra(EXTRA_LAT, Double.NaN);
        startLon = intent.getDoubleExtra(EXTRA_LON, Double.NaN);
        endLat = intent.getDoubleExtra(EXTRA_END_LAT, startLat);
        endLon = intent.getDoubleExtra(EXTRA_END_LON, startLon);
        routeMode = intent.getBooleanExtra(EXTRA_ROUTE, false);
        altitudeMeters = intent.getDoubleExtra(EXTRA_ALTITUDE, 0d);
        accuracyMeters = intent.getDoubleExtra(EXTRA_ACCURACY, 3d);
        speedMetersPerSec = intent.getDoubleExtra(EXTRA_SPEED_MPS, 0d);
        jitterMeters = intent.getDoubleExtra(EXTRA_JITTER, 0d);
        if (!valid(startLat,startLon) || (routeMode && !valid(endLat,endLon))
            || !Double.isFinite(altitudeMeters) || altitudeMeters < -1000d || altitudeMeters > 12000d
            || !Double.isFinite(accuracyMeters) || accuracyMeters < 1d || accuracyMeters > 10000d
            || !Double.isFinite(speedMetersPerSec) || speedMetersPerSec < 0d || speedMetersPerSec > 100d
            || !Double.isFinite(jitterMeters) || jitterMeters < 0d || jitterMeters > 200d) {
            error("Parametri GPS non validi"); finishSimulation(false); return START_NOT_STICKY;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            error("Permesso posizione mancante"); finishSimulation(false); return START_NOT_STICKY;
        }
        if (active) releaseProviders();
        latitude = startLat; longitude = startLon;
        routeDistanceMeters = routeMode ? distanceMeters(startLat,startLon,endLat,endLon) : 0d;
        if (routeMode && (routeDistanceMeters < 1d || speedMetersPerSec <= 0d)) {
            error("Percorso troppo breve o velocita' nulla"); finishSimulation(false); return START_NOT_STICKY;
        }
        bearing = routeMode ? bearingBetween(startLat,startLon,endLat,endLon) : 0f;
        progressedMeters = jitterX = jitterY = 0d;
        lastTickRealtime = SystemClock.elapsedRealtime();
        active = true; paused = false;
        try {
            foreground(createNotification());
            prepareProviders();
            if (installedProviders.isEmpty()) throw new SecurityException("App di posizione fittizia non selezionata");
            persistStatus();
            handler.removeCallbacks(tick); handler.post(tick);
        } catch (Exception e) {
            error("Controlla l'app di posizione fittizia: " + safeError(e));
            finishSimulation(false);
        }
        return START_NOT_STICKY;
    }

    private static boolean valid(double a,double b) {
        return Double.isFinite(a)&&Double.isFinite(b) && a>=-85.0511&&a<=85.0511&&b>=-180&&b<=180;
    }
    private void pauseSimulation() {
        paused = true; handler.removeCallbacks(tick); releaseProviders();
        persistStatus(); notifyChanged();
    }
    private void resumeSimulation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            error("Permesso posizione revocato"); finishSimulation(false); return;
        }
        try {
            prepareProviders();
            if (installedProviders.isEmpty()) throw new SecurityException("App di posizione fittizia non selezionata");
            paused = false; lastTickRealtime = SystemClock.elapsedRealtime();
            persistStatus(); notifyChanged();
            handler.removeCallbacks(tick); handler.post(tick);
        } catch (Exception e) { error("Ripresa fallita: " + safeError(e)); pauseSimulation(); }
    }
    private void foreground(Notification n) {
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(NOTIFICATION_ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        else startForeground(NOTIFICATION_ID,n);
    }
    private PendingIntent serviceAction(String action,int id) {
        Intent i = new Intent(this,MockLocationService.class).setAction(action);
        return PendingIntent.getService(this,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private Notification createNotification() {
        Intent open = new Intent(this,MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this,0,open,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String title = paused ? "LocationLab · In pausa" :
            (routeMode ? "LocationLab · Percorso attivo" : "LocationLab · Posizione attiva");
        String detail = String.format(Locale.US,"%.5f, %.5f",latitude,longitude);
        if (routeMode) detail = (routeDistanceMeters > 0 ? (int)Math.min(100d,100d*progressedMeters/routeDistanceMeters):0)
            + "% · " + detail;
        return new Notification.Builder(this,CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle(title).setContentText(detail).setContentIntent(content)
            .setOnlyAlertOnce(true).setOngoing(true)
            .addAction(new Notification.Action.Builder(
                paused ? android.R.drawable.ic_media_play:android.R.drawable.ic_media_pause,
                paused ? "Riprendi":"Pausa",serviceAction(paused?ACTION_RESUME:ACTION_PAUSE,1)).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,
                "Termina",serviceAction(ACTION_STOP,2)).build()).build();
    }
    private void notifyChanged() {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID,createNotification());
    }
    @SuppressWarnings("deprecation")
    private void prepareProvider(String provider) {
        try {
            manager.addTestProvider(provider,false,provider.equals(LocationManager.GPS_PROVIDER),false,
                false,true,true,true,Criteria.POWER_LOW,Criteria.ACCURACY_FINE);
            manager.setTestProviderEnabled(provider,true);
            installedProviders.add(provider);
        } catch (SecurityException e) {
            if (installedProviders.isEmpty()) throw e;
        } catch (IllegalArgumentException e) { /* altri provider possono essere disponibili */ }
    }
    private void prepareProviders() {
        prepareProvider(LocationManager.GPS_PROVIDER);
        prepareProvider(LocationManager.NETWORK_PROVIDER);
    }
    private void releaseProviders() {
        for(String provider:new HashSet<>(installedProviders)) {
            try { manager.removeTestProvider(provider); } catch (Exception ignored) { }
        }
        installedProviders.clear();
    }
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!active || paused) return;
            long now = SystemClock.elapsedRealtime();
            double elapsed = Math.min(5d,Math.max(0d,(now-lastTickRealtime)/1000d));
            lastTickRealtime = now;
            if (routeMode) {
                progressedMeters = Math.min(routeDistanceMeters,progressedMeters+speedMetersPerSec*elapsed);
                double t = routeDistanceMeters<=0 ? 1:progressedMeters/routeDistanceMeters;
                double[] point = interpolateGreatCircle(startLat,startLon,endLat,endLon,t);
                latitude=point[0];longitude=point[1];
            }
            if(jitterMeters>0) {
                jitterX=clamp(jitterX*.82+random.nextGaussian()*jitterMeters*.16,-jitterMeters,jitterMeters);
                jitterY=clamp(jitterY*.82+random.nextGaussian()*jitterMeters*.16,-jitterMeters,jitterMeters);
                double r=Math.hypot(jitterX,jitterY);
                if(r>jitterMeters){jitterX*=jitterMeters/r;jitterY*=jitterMeters/r;}
            } else jitterX=jitterY=0;
            double lat=clamp(latitude+Math.toDegrees(jitterY/EARTH_METERS),-85.051,85.051);
            double cos=Math.max(.085,Math.cos(Math.toRadians(latitude)));
            double lon=normalizeLon(longitude+Math.toDegrees(jitterX/(EARTH_METERS*cos)));
            for(String provider:new HashSet<>(installedProviders)){
                try {
                    Location location = new Location(provider);
                    location.setLatitude(lat); location.setLongitude(lon);
                    location.setAltitude(altitudeMeters); location.setAccuracy((float)accuracyMeters);
                    location.setBearing(bearing); location.setSpeed((float)speedMetersPerSec);
                    location.setTime(System.currentTimeMillis());
                    location.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
                    manager.setTestProviderLocation(provider,location);
                } catch(Exception e){installedProviders.remove(provider);}
            }
            if(installedProviders.isEmpty()){
                error("Provider GPS simulato non disponibile");finishSimulation(false);return;
            }
            persistStatus();
            if(now-lastNoticeRealtime>=5000L){lastNoticeRealtime=now;notifyChanged();}
            if(routeMode && progressedMeters>=routeDistanceMeters){finishSimulation(true);return;}
            handler.postDelayed(this,1000L);
        }
    };
    private void persistStatus() {
        getSharedPreferences("state",MODE_PRIVATE).edit()
            .putBoolean("running",active&&!paused).putBoolean("paused",active&&paused)
            .putBoolean("routeRunning",routeMode&&active)
            .putLong("liveLat",Double.doubleToRawLongBits(latitude))
            .putLong("liveLon",Double.doubleToRawLongBits(longitude))
            .putInt("routePercent",routeDistanceMeters>0?(int)Math.min(100d,100d*progressedMeters/routeDistanceMeters):0)
            .apply();
    }
    private void error(String msg){getSharedPreferences("state",MODE_PRIVATE).edit().putString("error",msg).apply();}
    private static String safeError(Exception e){return e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();}
    private void finishSimulation(boolean completed) {
        active=paused=false; handler.removeCallbacks(tick); releaseProviders();persistStatus();
        if(completed)getSharedPreferences("state",MODE_PRIVATE).edit().putBoolean("routeCompleted",true).apply();
        stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
    }
    private static double clamp(double n,double lo,double hi){return Math.max(lo,Math.min(hi,n));}
    private static double normalizeLon(double n){return(n+540d)%360d-180d;}
    static double distanceMeters(double lat1,double lon1,double lat2,double lon2){
        double dLat=Math.toRadians(lat2-lat1),dLon=Math.toRadians(lon2-lon1);
        double a=Math.pow(Math.sin(dLat/2),2)+Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))*Math.pow(Math.sin(dLon/2),2);
        return 2*EARTH_METERS*Math.asin(Math.min(1d,Math.sqrt(a)));
    }
    private static float bearingBetween(double lat1,double lon1,double lat2,double lon2){
        double a=Math.toRadians(lat1),b=Math.toRadians(lat2),d=Math.toRadians(lon2-lon1);
        double y=Math.sin(d)*Math.cos(b);
        double x=Math.cos(a)*Math.sin(b)-Math.sin(a)*Math.cos(b)*Math.cos(d);
        return(float)((Math.toDegrees(Math.atan2(y,x))+360)%360);
    }
    static double[] interpolateGreatCircle(double lat1,double lon1,double lat2,double lon2,double t){
        t=clamp(t,0,1);
        double a=Math.toRadians(lat1),b=Math.toRadians(lon1),c=Math.toRadians(lat2),d=Math.toRadians(lon2);
        double dot=Math.sin(a)*Math.sin(c)+Math.cos(a)*Math.cos(c)*Math.cos(d-b);
        double angle=Math.acos(clamp(dot,-1,1));
        if(angle<1e-9)return new double[]{lat1,lon1};
        double sin=Math.sin(angle);
        if(Math.abs(sin)<1e-8)return new double[]{lat1+(lat2-lat1)*t,normalizeLon(lon1+(lon2-lon1)*t)};
        double m=Math.sin((1-t)*angle)/sin,n=Math.sin(t*angle)/sin;
        double x=m*Math.cos(a)*Math.cos(b)+n*Math.cos(c)*Math.cos(d);
        double y=m*Math.cos(a)*Math.sin(b)+n*Math.cos(c)*Math.sin(d);
        double z=m*Math.sin(a)+n*Math.sin(c);
        return new double[]{Math.toDegrees(Math.atan2(z,Math.hypot(x,y))),normalizeLon(Math.toDegrees(Math.atan2(y,x)))};
    }
    @Override public void onDestroy(){active=paused=false;handler.removeCallbacks(tick);releaseProviders();persistStatus();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
