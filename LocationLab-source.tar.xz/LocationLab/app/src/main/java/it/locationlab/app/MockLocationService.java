package it.locationlab.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.*;
import android.os.*;
import android.provider.Settings;
import java.util.*;

/** Iniezione di posizioni TEST attraverso le API pubbliche Android, senza root. */
public final class MockLocationService extends Service {
    public static final String ACTION_START = "it.locationlab.app.START";
    public static final String ACTION_STOP = "it.locationlab.app.STOP";
    public static final String EXTRA_LAT = "lat";
    public static final String EXTRA_LON = "lon";
    private static final int NOTIFICATION_ID = 501;
    private static final String CHANNEL_ID = "mock_gps";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LocationManager manager;
    private boolean active;
    private double latitude, longitude;
    private final Set<String> installedProviders = new HashSet<>();

    @Override public void onCreate() {
        super.onCreate();
        manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Posizione simulata", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Indica quando LocationLab sta simulando la posizione");
            nm.createNotificationChannel(ch);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopSimulation(); return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;
        latitude = intent.getDoubleExtra(EXTRA_LAT, 0d);
        longitude = intent.getDoubleExtra(EXTRA_LON, 0d);
        if (!Double.isFinite(latitude) || !Double.isFinite(longitude) || Math.abs(latitude) > 90 || Math.abs(longitude) > 180) {
            stopSimulation(); return START_NOT_STICKY;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSimulation(); return START_NOT_STICKY;
        }
        try {
            Notification n = createNotification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(NOTIFICATION_ID, n);
            }
            active = true;
            getSharedPreferences("state", MODE_PRIVATE).edit().putBoolean("running", true).apply();
            prepareProvider(LocationManager.GPS_PROVIDER);
            prepareProvider(LocationManager.NETWORK_PROVIDER);
            if (installedProviders.isEmpty()) throw new SecurityException("Nessun provider mock disponibile");
            handler.removeCallbacks(tick);
            handler.post(tick);
        } catch (Exception ex) {
            getSharedPreferences("state", MODE_PRIVATE).edit().putString("error", ex.getMessage()).apply();
            stopSimulation();
        }
        return START_NOT_STICKY;
    }

    private Notification createNotification() {
        Intent launch = new Intent(this, MainActivity.class);
        PendingIntent open = PendingIntent.getActivity(this, 0, launch,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, MockLocationService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("LocationLab · GPS simulato")
            .setContentText(String.format(Locale.US, "%.6f, %.6f", latitude, longitude))
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(new Notification.Action.Builder(
                android.R.drawable.ic_media_pause, "Ferma", stopPi).build())
            .build();
    }

    @SuppressWarnings("deprecation")
    private void prepareProvider(String provider) {
        try {
            manager.addTestProvider(provider, false, provider.equals(LocationManager.GPS_PROVIDER), false,
                false, true, true, true, android.location.Criteria.POWER_LOW, android.location.Criteria.ACCURACY_FINE);
            manager.setTestProviderEnabled(provider, true);
            installedProviders.add(provider);
        } catch (SecurityException ex) {
            // Su alcuni firmware il mock GPS funziona, mentre quello di rete no.
            // Non interrompiamo un provider già attivato.
            if (installedProviders.isEmpty()) throw ex;
        } catch (IllegalArgumentException ex) {
            // Un provider può non essere disponibile su alcuni dispositivi.
        }
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!active) return;
            for (String provider : new HashSet<>(installedProviders)) {
                try {
                    Location position = new Location(provider);
                    position.setLatitude(latitude);
                    position.setLongitude(longitude);
                    position.setAccuracy(3f);
                    position.setAltitude(0d);
                    position.setBearing(0f);
                    position.setSpeed(0f);
                    position.setTime(System.currentTimeMillis());
                    position.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());
                    manager.setTestProviderLocation(provider, position);
                } catch (Exception ex) {
                    installedProviders.remove(provider);
                }
            }
            if (installedProviders.isEmpty()) { stopSimulation(); return; }
            handler.postDelayed(this, 1000);
        }
    };

    private void stopSimulation() {
        active = false;
        getSharedPreferences("state", MODE_PRIVATE).edit().putBoolean("running", false).apply();
        handler.removeCallbacks(tick);
        for (String provider : new HashSet<>(installedProviders)) {
            try { manager.removeTestProvider(provider); } catch (Exception ignored) { }
        }
        installedProviders.clear();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override public void onDestroy() {
        active = false;
        getSharedPreferences("state", MODE_PRIVATE).edit().putBoolean("running", false).apply();
        handler.removeCallbacks(tick);
        for (String provider : new HashSet<>(installedProviders)) {
            try { manager.removeTestProvider(provider); } catch (Exception ignored) { }
        }
        installedProviders.clear();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
