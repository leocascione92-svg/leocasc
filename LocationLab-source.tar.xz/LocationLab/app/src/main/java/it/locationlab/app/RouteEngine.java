package it.locationlab.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Creazione e archiviazione degli itinerari. Le modalita' a piedi e auto usano
 * i grafi stradali/pedonali OSRM di FOSSGIS. Le richieste sono fatte solamente
 * quando l'utente sceglie esplicitamente un itinerario.
 *
 * Endpoint pubblico, un solo calcolo alla volta, nessuna scansione o caching
 * indiscriminato. Se manca la rete o il servizio e' indisponibile NON e'
 * prodotta una finta rotta stradale in linea retta.
 */
public final class RouteEngine {
    private RouteEngine() { }
    private static final String FILE = "locationlab_route.json";
    private static final int MAX_POINT_COUNT = 2400;
    private static final int MAX_JSON_BYTES = 3_000_000;
    private static long lastRoutingRequestMillis = 0L;
    private static synchronized void throttleRequests() throws InterruptedException {
        long now = android.os.SystemClock.elapsedRealtime();
        long wait = 1100L - (now-lastRoutingRequestMillis);
        if(wait>0)Thread.sleep(wait);
        lastRoutingRequestMillis = android.os.SystemClock.elapsedRealtime();
    }
    public static final String FOOT = "foot";
    public static final String CAR = "car";
    public static final String PLANE = "plane";

    public static final class Plan {
        public final String profile;
        public final double[][] points;  // [lat, lon]
        public final double distanceMeters;
        public final double timeSeconds;
        Plan(String profile, double[][] points, double distanceMeters, double timeSeconds) {
            this.profile = profile;
            this.points = points;
            this.distanceMeters = distanceMeters;
            this.timeSeconds = timeSeconds;
        }
        public double firstLat() { return points[0][0]; }
        public double firstLon() { return points[0][1]; }
        public double lastLat() { return points[points.length-1][0]; }
        public double lastLon() { return points[points.length-1][1]; }
    }

    public static String profileName(String profile) {
        if (FOOT.equals(profile)) return "A piedi";
        if (CAR.equals(profile)) return "In auto";
        if (PLANE.equals(profile)) return "In aereo";
        return "Percorso";
    }

    public static Plan calculate(String profile, double startLat, double startLon,
                                 double destLat, double destLon) throws Exception {
        if (!valid(startLat,startLon) || !valid(destLat,destLon))
            throw new IOException("Coordinate non valide");
        if (MockLocationService.distanceMeters(startLat,startLon,destLat,destLon) < 2d)
            throw new IOException("Partenza e destinazione coincidono");
        if (PLANE.equals(profile)) {
            double[][] points = new double[129][2];
            for (int i=0;i<points.length;i++) {
                points[i] = MockLocationService.interpolateGreatCircle(startLat,startLon,
                    destLat,destLon,(double)i/(points.length-1));
            }
            return createPlan(profile,points,0d);
        }
        if (!CAR.equals(profile) && !FOOT.equals(profile)) throw new IOException("Modalita' non disponibile");
        // Il backend seleziona gia' il profilo; per OSRM la stringa URL e' "driving" anche
        // quando il backend /routed-foot e' stato preparato per i pedoni.
        String endpoint = CAR.equals(profile) ? "routed-car" : "routed-foot";
        String path = String.format(Locale.US,
            "https://routing.openstreetmap.de/%s/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=full&geometries=geojson&steps=false",
            endpoint,startLon,startLat,destLon,destLat);
        HttpURLConnection conn = null;
        try {
            throttleRequests();
            conn = (HttpURLConnection)new URL(path).openConnection();
            conn.setRequestProperty("User-Agent", "LocationLab/3.0 (Android route viewer; https://github.com/leocascione92-svg/leocasc)");
            conn.setRequestProperty("Accept", "application/json");
            conn.setConnectTimeout(11000);
            conn.setReadTimeout(20000);
            conn.setInstanceFollowRedirects(false);
            int code = conn.getResponseCode();
            if (code == 429) throw new IOException("Servizio itinerari occupato. Riprova tra poco.");
            if (code < 200 || code >= 300) throw new IOException("Servizio itinerari non disponibile ("+code+")");
            String response = readLimited(conn.getInputStream(),MAX_JSON_BYTES);
            JSONObject root = new JSONObject(response);
            if (!"Ok".equals(root.optString("code"))) {
                throw new IOException("Nessun itinerario " + (FOOT.equals(profile)?"pedonale":"automobilistico") + " trovato");
            }
            JSONArray routes = root.optJSONArray("routes");
            if (routes == null || routes.length() == 0)
                throw new IOException("Nessun itinerario su strade o sentieri disponibile");
            JSONObject best = routes.getJSONObject(0);
            JSONObject geometry = best.getJSONObject("geometry");
            JSONArray coordinates = geometry.getJSONArray("coordinates");
            if (coordinates.length()<2 || coordinates.length()>100000)
                throw new IOException("Itinerario troppo lungo o non valido");
            double[][] raw = new double[coordinates.length()][2];
            for (int i=0;i<coordinates.length();i++) {
                JSONArray pair = coordinates.getJSONArray(i);
                if (pair.length()<2) throw new IOException("Geometria percorso non valida");
                double lon = pair.getDouble(0), lat = pair.getDouble(1);
                if (!valid(lat,lon)) throw new IOException("Coordinate percorso non valide");
                raw[i][0] = lat; raw[i][1] = lon;
            }
            double[][] points = simplify(raw, MAX_POINT_COUNT);
            return createPlan(profile,points,best.optDouble("duration",0d));
        } finally { if (conn != null) conn.disconnect(); }
    }

    private static Plan createPlan(String profile,double[][] points,double seconds) throws IOException {
        double total = 0d;
        for (int i=1;i<points.length;i++)
            total += MockLocationService.distanceMeters(points[i-1][0],points[i-1][1],points[i][0],points[i][1]);
        if (!(total>1d) || !Double.isFinite(total)) throw new IOException("Percorso non valido");
        return new Plan(profile, points, total, Math.max(0d,seconds));
    }

    private static String readLimited(InputStream stream,int max) throws IOException {
        try (InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] block = new byte[8192]; int n;
            while ((n=in.read(block))!=-1) {
                if (Thread.currentThread().isInterrupted()) throw new IOException("Calcolo annullato");
                if (out.size()+n>max) throw new IOException("Risposta del servizio troppo grande");
                out.write(block,0,n);
            }
            return out.toString("UTF-8");
        }
    }

    /** Riduce una rotta dettagliata soltanto se supera la soglia di 2400 punti. */
    private static double[][] simplify(double[][] raw,int max) {
        if (raw.length<=max) return raw;
        // Semplificazione Douglas-Peucker con tolleranza adattiva: conserva le curve.
        double tolerance = 2d;
        int[] kept = null;
        while (tolerance<=1024d) {
            boolean[] yes=new boolean[raw.length]; yes[0]=true; yes[raw.length-1]=true;
            ArrayDeque<int[]> stack = new ArrayDeque<>(); stack.push(new int[]{0,raw.length-1});
            while(!stack.isEmpty()) {
                int[] span=stack.pop(); int a=span[0],b=span[1],index=-1;
                double furthest=0;
                for(int i=a+1;i<b;i++) {
                    double d = deviationMeters(raw[a],raw[b],raw[i]);
                    if(d>furthest){furthest=d;index=i;}
                }
                if(index>0 && furthest>tolerance) {
                    yes[index]=true;stack.push(new int[]{a,index});stack.push(new int[]{index,b});
                }
            }
            int count=0;for(boolean k:yes)if(k)count++;
            if(count<=max) {
                kept=new int[count];int j=0;for(int i=0;i<yes.length;i++)if(yes[i])kept[j++]=i;
                break;
            }
            tolerance*=2d;
        }
        if(kept==null){
            kept=new int[max]; for(int i=0;i<max;i++)kept[i]=Math.round((float)i/(max-1)*(raw.length-1));
        }
        double[][] out=new double[kept.length][2];
        for(int i=0;i<kept.length;i++)out[i]=raw[kept[i]];
        return out;
    }
    private static double deviationMeters(double[] a,double[] b,double[] p) {
        double rad = Math.PI/180d, r=6371000d;
        double cy=Math.cos((a[0]+b[0])*.5*rad);
        double bx=(b[1]-a[1])*rad*r*cy, by=(b[0]-a[0])*rad*r;
        double px=(p[1]-a[1])*rad*r*cy, py=(p[0]-a[0])*rad*r;
        double denom=bx*bx+by*by;
        double t=denom>0?Math.max(0d,Math.min(1d,(px*bx+py*by)/denom)):0d;
        return Math.hypot(px-bx*t,py-by*t);
    }

    public static void save(Context context,Plan plan) throws IOException {
        if(plan==null || plan.points.length<2) throw new IOException("Percorso vuoto");
        JSONObject obj=new JSONObject();
        try {
            obj.put("version",1).put("profile",plan.profile)
                .put("seconds",plan.timeSeconds).put("meters",plan.distanceMeters);
            JSONArray points=new JSONArray();
            for(double[] pair:plan.points) { JSONArray pt=new JSONArray();pt.put(pair[0]).put(pair[1]);points.put(pt); }
            obj.put("points",points);
        } catch (org.json.JSONException e) { throw new IOException("Impossibile salvare il percorso",e); }
        File temp=new File(context.getFilesDir(),FILE+".tmp");
        File target=new File(context.getFilesDir(),FILE);
        try(FileOutputStream out=new FileOutputStream(temp)) {
            byte[] bytes=obj.toString().getBytes(StandardCharsets.UTF_8);
            out.write(bytes);out.getFD().sync();
        }
        if (!temp.renameTo(target)) {
            // Alcuni file system impediscono l'overwrite tramite rename: usa copia locale.
            try(FileInputStream in=new FileInputStream(temp);FileOutputStream out=new FileOutputStream(target)) {
                byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);
            }
            if(!temp.delete())temp.deleteOnExit();
        }
    }

    public static Plan load(Context ctx) {
        File file=new File(ctx.getFilesDir(),FILE);
        if(!file.isFile()||file.length()>MAX_JSON_BYTES||file.length()<10)return null;
        try {
            String json=readLimited(new FileInputStream(file),MAX_JSON_BYTES);
            JSONObject obj=new JSONObject(json);if(obj.optInt("version")!=1)return null;
            String profile=obj.getString("profile");
            if(!FOOT.equals(profile)&&!CAR.equals(profile)&&!PLANE.equals(profile))return null;
            JSONArray raw=obj.getJSONArray("points");
            if(raw.length()<2||raw.length()>MAX_POINT_COUNT)return null;
            double[][] points=new double[raw.length()][2];
            for(int i=0;i<points.length;i++){
                JSONArray p=raw.getJSONArray(i);
                points[i][0]=p.getDouble(0);points[i][1]=p.getDouble(1);
                if(!valid(points[i][0],points[i][1]))return null;
            }
            return createPlan(profile,points,obj.optDouble("seconds",0d));
        } catch(Exception ex){return null;}
    }

    public static void delete(Context ctx) {
        File f=new File(ctx.getFilesDir(),FILE); if(f.exists())f.delete();
    }
    private static boolean valid(double lat,double lon) {
        return Double.isFinite(lat)&&Double.isFinite(lon)
            && lat>=-85.0511&&lat<=85.0511&&lon>=-180d&&lon<=180d;
    }
}
