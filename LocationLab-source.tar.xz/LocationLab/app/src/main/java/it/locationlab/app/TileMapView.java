package it.locationlab.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.VelocityTracker;
import android.view.View;
import android.widget.OverScroller;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/** Mappa OSM senza SDK, con zoom progressivo e scorrimento inerziale. */
public final class TileMapView extends View {
    public interface OnSelectedListener { void onSelected(double latitude, double longitude); }
    private OnSelectedListener listener;
    private final Paint tilePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint shapePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ColorMatrixColorFilter nightFilter = new ColorMatrixColorFilter(new float[]{
        -.12f, -.39f, -.055f, 0f, 188f,
        -.12f, -.39f, -.055f, 0f, 198f,
        -.12f, -.39f, -.055f, 0f, 214f,
        0f, 0f, 0f, 1f, 0f
    });
    private final LruCache<String, Bitmap> memory = new LruCache<String, Bitmap>(40 * 1024) {
        @Override protected int sizeOf(String key, Bitmap bmp) { return bmp.getByteCount() / 1024; }
    };
    private final ExecutorService io = Executors.newFixedThreadPool(4);
    private final Set<String> inflight = Collections.synchronizedSet(new HashSet<>());
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ScaleGestureDetector detector;
    private final OverScroller scroller;
    private final File tileCache;
    private VelocityTracker velocity;
    private double centerLat = 41.893, centerLon = 12.483;
    private double selectedLat = centerLat, selectedLon = centerLon;
    private double zoomLevel = 13.0;
    private float prevX, prevY, downX, downY;
    private int scrollerX, scrollerY;
    private boolean dragged, multiTouch;
    private boolean darkMode = true;

    public TileMapView(Context context) {
        super(context);
        tileCache = new File(context.getCacheDir(), "osm-tiles");
        scroller = new OverScroller(context);
        detector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                double factor = d.getScaleFactor();
                if (Double.isFinite(factor) && factor > 0d) zoomAround(Math.log(factor) / Math.log(2d), d.getFocusX(), d.getFocusY());
                return true;
            }
        });
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    public void setDarkMode(boolean dark) { darkMode = dark; invalidate(); }
    public boolean isDarkMode() { return darkMode; }
    public void setOnSelectedListener(OnSelectedListener l) { listener = l; }
    public void setPosition(double lat, double lon, boolean recenter) {
        selectedLat = clamp(lat, -85.0511, 85.0511);
        selectedLon = normalizeLon(lon);
        if (recenter) { centerLat = selectedLat; centerLon = selectedLon; }
        invalidate();
    }
    public void zoomBy(int delta) { zoomAround(delta, getWidth()/2f, getHeight()/2f); }
    private static double clamp(double n, double a, double b) { return Math.max(a, Math.min(b, n)); }
    private static double normalizeLon(double lon) { return (lon + 540d) % 360d - 180d; }
    private double world() { return 256d * Math.pow(2d, zoomLevel); }
    private double lonX(double lon) { return (lon + 180d) / 360d * world(); }
    private double latY(double lat) {
        double r = Math.toRadians(clamp(lat, -85.0511, 85.0511));
        return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2d * world();
    }
    private double xLon(double x) { return normalizeLon(x / world() * 360d - 180d); }
    private double yLat(double y) { return Math.toDegrees(Math.atan(Math.sinh(Math.PI * (1d - 2d * y / world())))); }
    private void zoomAround(double delta, float focalX, float focalY) {
        double next = clamp(zoomLevel + delta, 2d, 18.75d);
        if (next == zoomLevel) return;
        double anchorLon = xLon(lonX(centerLon) + focalX - getWidth()/2d);
        double anchorLat = yLat(latY(centerLat) + focalY - getHeight()/2d);
        zoomLevel = next;
        centerLon = xLon(lonX(anchorLon) - focalX + getWidth()/2d);
        centerLat = yLat(clamp(latY(anchorLat) - focalY + getHeight()/2d, 0, world()));
        postInvalidateOnAnimation();
    }
    private void pan(float dx, float dy) {
        centerLon = xLon(lonX(centerLon) - dx);
        centerLat = yLat(clamp(latY(centerLat) - dy, 0, world()));
        postInvalidateOnAnimation();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        c.drawColor(darkMode ? Color.rgb(36, 49, 63) : Color.rgb(225, 231, 225));
        int z = (int)Math.floor(zoomLevel);
        double scale = Math.pow(2d, zoomLevel - z);
        double edge = 256d * scale;
        double left = lonX(centerLon) - getWidth()/2d;
        double top = latY(centerLat) - getHeight()/2d;
        int startX = (int)Math.floor(left/edge), endX = (int)Math.floor((left+getWidth())/edge);
        int startY = (int)Math.floor(top/edge), endY = (int)Math.floor((top+getHeight())/edge);
        int count = 1 << z;
        tilePaint.setColorFilter(darkMode ? nightFilter : null);
        for (int x=startX; x<=endX; x++) for(int y=startY; y<=endY; y++) {
            if (y<0 || y>=count) continue;
            int ix = Math.floorMod(x, count);
            float px = (float)(x*edge-left), py=(float)(y*edge-top);
            RectF dest = new RectF(px, py, (float)(px+edge+0.6), (float)(py+edge+0.6));
            String key = z+"/"+ix+"/"+y;
            Bitmap bmp = memory.get(key);
            if (bmp!=null && !bmp.isRecycled()) {
                c.drawBitmap(bmp, null, dest, tilePaint);
            } else {
                // Durante il pinch, riutilizza le tile parent già in memoria;
                // evita il flash di riquadri vuoti tra due livelli di zoom.
                boolean fallback = false;
                if (z>2) {
                    Bitmap parent = memory.get((z-1)+"/"+(ix/2)+"/"+(y/2));
                    if (parent!=null && !parent.isRecycled()) {
                        int sx=(ix&1)*parent.getWidth()/2, sy=(y&1)*parent.getHeight()/2;
                        Rect region = new Rect(sx, sy, sx+parent.getWidth()/2, sy+parent.getHeight()/2);
                        c.drawBitmap(parent, region, dest, tilePaint);
                        fallback = true;
                    }
                }
                if (!fallback) {
                    shapePaint.setColor(darkMode ? Color.rgb(43, 58, 74) : Color.rgb(215, 226, 219));
                    c.drawRect(dest, shapePaint);
                }
                queueTile(key,z,ix,y);
            }
        }
        tilePaint.setColorFilter(null);
        double px = lonX(selectedLon)-left;
        if (px>getWidth()+32) px-=world();
        if (px < -32) px+=world();
        float x=(float)px, y=(float)(latY(selectedLat)-top);
        shapePaint.setColor(Color.argb(60, 12, 16, 27)); c.drawCircle(x,y,27,shapePaint);
        shapePaint.setColor(Color.WHITE); c.drawCircle(x,y,14,shapePaint);
        shapePaint.setColor(Color.rgb(12, 178, 151)); c.drawCircle(x,y,10,shapePaint);
        shapePaint.setColor(Color.WHITE); c.drawCircle(x,y,3,shapePaint);
    }

    private void queueTile(String key,int z,int x,int y) {
        if (!inflight.add(key)) return;
        io.execute(() -> {
            try {
                File file=new File(tileCache,key+".png");
                Bitmap bmp=null;
                // OSM tile policy: cache locale per almeno sette giorni.
                if (file.isFile() && System.currentTimeMillis()-file.lastModified()<7L*86400000L) {
                    bmp=BitmapFactory.decodeFile(file.getAbsolutePath());
                }
                if (bmp==null) {
                    URL url=new URL("https://tile.openstreetmap.org/"+z+"/"+x+"/"+y+".png");
                    HttpURLConnection connection=(HttpURLConnection)url.openConnection();
                    connection.setRequestProperty("User-Agent","LocationLab/0.3 (Android; github.com/leocascione92-svg/leocasc)");
                    connection.setConnectTimeout(6000); connection.setReadTimeout(8000);
                    try {
                        if (connection.getResponseCode()==200) {
                            try(InputStream stream=connection.getInputStream();ByteArrayOutputStream bytes=new ByteArrayOutputStream()) {
                                byte[] buffer=new byte[4096];int n;
                                while((n=stream.read(buffer))!=-1) bytes.write(buffer,0,n);
                                byte[] data=bytes.toByteArray();
                                bmp=BitmapFactory.decodeByteArray(data,0,data.length);
                                if(bmp!=null) {
                                    file.getParentFile().mkdirs();
                                    try(FileOutputStream out=new FileOutputStream(file)) {out.write(data);}
                                }
                            }
                        }
                    } finally {connection.disconnect();}
                }
                Bitmap result=bmp;
                if(result!=null) main.post(() -> {memory.put(key,result); postInvalidateOnAnimation();});
            } catch (Exception ignored) { /* mappa utilizzabile con tile in cache */ }
            finally {inflight.remove(key);}
        });
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        detector.onTouchEvent(event);
        switch(event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                scroller.forceFinished(true);
                if (velocity!=null) velocity.recycle();
                velocity=VelocityTracker.obtain(); velocity.addMovement(event);
                downX=prevX=event.getX();downY=prevY=event.getY();
                dragged=false;multiTouch=false;
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                multiTouch=true; dragged=true;
                return true;
            case MotionEvent.ACTION_MOVE:
                if(velocity!=null) velocity.addMovement(event);
                if (event.getPointerCount()>1 || detector.isInProgress()) {dragged=true;return true;}
                float xx=event.getX(), yy=event.getY();
                if(Math.hypot(xx-downX,yy-downY)>10*getResources().getDisplayMetrics().density) dragged=true;
                if(dragged && !multiTouch) pan(xx-prevX,yy-prevY);
                prevX=xx;prevY=yy;
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                dragged=true;multiTouch=true;
                return true;
            case MotionEvent.ACTION_UP:
                if (velocity!=null) {
                    velocity.addMovement(event);
                    if(dragged && !multiTouch) {
                        velocity.computeCurrentVelocity(1000);
                        int vx=(int)velocity.getXVelocity(),vy=(int)velocity.getYVelocity();
                        if(Math.abs(vx)>350 || Math.abs(vy)>350) {
                            scrollerX=0;scrollerY=0;
                            scroller.fling(0,0,vx,vy,Integer.MIN_VALUE,Integer.MAX_VALUE,Integer.MIN_VALUE,Integer.MAX_VALUE);
                            postInvalidateOnAnimation();
                        }
                    }
                    velocity.recycle();velocity=null;
                }
                if (!dragged && !multiTouch && !detector.isInProgress()) {
                    double lat=yLat(latY(centerLat)+event.getY()-getHeight()/2d);
                    double lon=xLon(lonX(centerLon)+event.getX()-getWidth()/2d);
                    setPosition(lat,lon,false);
                    if(listener!=null) listener.onSelected(selectedLat,selectedLon);
                }
                performClick();return true;
            case MotionEvent.ACTION_CANCEL:
                if(velocity!=null) {velocity.recycle();velocity=null;}
                return true;
            default:return true;
        }
    }
    @Override public void computeScroll() {
        if(scroller.computeScrollOffset()) {
            int nx=scroller.getCurrX(), ny=scroller.getCurrY();
            pan(nx-scrollerX,ny-scrollerY);
            scrollerX=nx;scrollerY=ny;
            postInvalidateOnAnimation();
        }
    }
    @Override public boolean performClick() {super.performClick();return true;}
    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();scroller.forceFinished(true);io.shutdownNow();
    }
}
