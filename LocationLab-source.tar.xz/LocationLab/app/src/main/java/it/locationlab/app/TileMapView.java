package it.locationlab.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.VelocityTracker;
import android.view.View;
import android.widget.OverScroller;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.concurrent.*;

/**
 * Mappa OSM a scorrimento continuo.
 *
 * Durante gli spostamenti utilizza quanto gia' disegnato e le tile presenti in
 * cache: nessun download di aree non visibili, nessuna pre-cache offline.
 */
public final class TileMapView extends View {
    public interface OnSelectedListener { void onSelected(double latitude, double longitude); }
    private OnSelectedListener listener;

    private final Paint tilePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final Paint previewPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final Paint shapePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ColorMatrixColorFilter nightFilter = new ColorMatrixColorFilter(new float[]{
        -.12f, -.39f, -.055f, 0f, 188f,
        -.12f, -.39f, -.055f, 0f, 198f,
        -.12f, -.39f, -.055f, 0f, 214f,
        0f, 0f, 0f, 1f, 0f
    });
    // La cache RAM conserva anche le tile gia' attraversate, per tornare
    // indietro immediatamente senza quadrati vuoti e senza traffico dati.
    private final LruCache<String, Bitmap> memory = new LruCache<String, Bitmap>(64 * 1024) {
        @Override protected int sizeOf(String key, Bitmap bmp) { return Math.max(1, bmp.getByteCount() / 1024); }
    };
    // Soltanto due connessioni alla volta verso i server della community OSM.
    private final ThreadPoolExecutor io = new ThreadPoolExecutor(2, 2, 0L,
        TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>());
    private final ConcurrentHashMap<String, TileTask> inflight = new ConcurrentHashMap<>();
    private volatile Set<String> visibleKeys = Collections.emptySet();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ScaleGestureDetector detector;
    private final OverScroller scroller;
    private final File tileCache;
    private VelocityTracker velocity;
    private double centerLat = 41.893, centerLon = 12.483;
    private double selectedLat = centerLat, selectedLon = centerLon;
    private double zoomLevel = 13.0;
    private float prevX, prevY, downX, downY;
    private int scrollerX, scrollerY;
    private boolean dragged, multiTouch, fingerDown;
    private boolean darkMode = true;

    // Un fotogramma gia' renderizzato della mappa (senza il marcatore) resta
    // ancorato alle coordinate geografiche mentre le nuove tile sono in viaggio.
    private Bitmap lastMapFrame;
    private double frameLat, frameLon, frameZoom;
    private boolean frameDark;
    private long frameTime;
    private static final int TILE_PX = 256;

    public TileMapView(Context context) {
        super(context);
        tileCache = new File(context.getCacheDir(), "osm-tiles");
        scroller = new OverScroller(context);
        detector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                double factor = d.getScaleFactor();
                if (Double.isFinite(factor) && factor > 0d)
                    zoomAround(Math.log(factor) / Math.log(2d), d.getFocusX(), d.getFocusY());
                return true;
            }
        });
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    public void setDarkMode(boolean dark) {
        if (darkMode != dark) { darkMode = dark; clearFrame(); }
        postInvalidateOnAnimation();
    }
    public boolean isDarkMode() { return darkMode; }
    public void setOnSelectedListener(OnSelectedListener l) { listener = l; }
    public void setPosition(double lat, double lon, boolean recenter) {
        selectedLat = clamp(lat, -85.0511, 85.0511);
        selectedLon = normalizeLon(lon);
        if (recenter) { centerLat = selectedLat; centerLon = selectedLon; scroller.forceFinished(true); }
        postInvalidateOnAnimation();
    }
    public void zoomBy(int delta) { zoomAround(delta, getWidth()/2f, getHeight()/2f); }
    private static double clamp(double n, double a, double b) { return Math.max(a, Math.min(b, n)); }
    private static double normalizeLon(double lon) { return (lon + 540d) % 360d - 180d; }
    private static double world(double z) { return TILE_PX * Math.pow(2d, z); }
    private double world() { return world(zoomLevel); }
    private static double lonX(double lon, double z) { return (lon + 180d) / 360d * world(z); }
    private double lonX(double lon) { return lonX(lon, zoomLevel); }
    private static double latY(double lat, double z) {
        double r = Math.toRadians(clamp(lat, -85.0511, 85.0511));
        return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2d * world(z);
    }
    private double latY(double lat) { return latY(lat, zoomLevel); }
    private double xLon(double x) { return normalizeLon(x / world() * 360d - 180d); }
    private double yLat(double y) { return Math.toDegrees(Math.atan(Math.sinh(Math.PI * (1d - 2d * y / world())))); }
    private void zoomAround(double delta, float focalX, float focalY) {
        double next = clamp(zoomLevel + delta, 2d, 18.75d);
        if (next == zoomLevel) return;
        double anchorLon = xLon(lonX(centerLon) + focalX - getWidth()/2d);
        double anchorLat = yLat(latY(centerLat) + focalY - getHeight()/2d);
        zoomLevel = next;
        centerLon = xLon(lonX(anchorLon) - focalX + getWidth()/2d);
        centerLat = yLat(clamp(latY(anchorLat) - focalY + getHeight()/2d, 0, world()));
        postInvalidateOnAnimation();
    }
    private void pan(float dx, float dy) {
        centerLon = xLon(lonX(centerLon) - dx);
        centerLat = yLat(clamp(latY(centerLat) - dy, 0, world()));
        postInvalidateOnAnimation();
    }

    private static final class Needed {
        final String key;
        final int z, x, y;
        final double distance;
        Needed(String key, int z, int x, int y, double distance) {
            this.key = key; this.z = z; this.x = x; this.y = y; this.distance = distance;
        }
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() <= 0 || getHeight() <= 0) return;
        canvas.drawColor(darkMode ? Color.rgb(36, 49, 63) : Color.rgb(225, 231, 225));
        drawPreviousFrame(canvas);

        int z = (int)Math.floor(zoomLevel);
        double scale = Math.pow(2d, zoomLevel - z);
        double edge = TILE_PX * scale;
        double left = lonX(centerLon) - getWidth()/2d;
        double top = latY(centerLat) - getHeight()/2d;
        int startX = (int)Math.floor(left/edge), endX = (int)Math.floor((left+getWidth())/edge);
        int startY = (int)Math.floor(top/edge), endY = (int)Math.floor((top+getHeight())/edge);
        int count = 1 << z;
        Set<String> wanted = new HashSet<>();
        ArrayList<Needed> need = new ArrayList<>();
        boolean complete = true;
        tilePaint.setColorFilter(darkMode ? nightFilter : null);
        for (int x=startX; x<=endX; x++) for(int y=startY; y<=endY; y++) {
            if (y<0 || y>=count) continue;
            int ix = Math.floorMod(x, count);
            float px = (float)(x*edge-left), py=(float)(y*edge-top);
            RectF dest = new RectF(px, py, (float)(px+edge+0.5), (float)(py+edge+0.5));
            String key = z+"/"+ix+"/"+y;
            wanted.add(key);
            Bitmap bmp = memory.get(key);
            if (isUsable(bmp)) {
                canvas.drawBitmap(bmp, null, dest, tilePaint);
            } else {
                complete = false;
                // Usa tile gia' viste a risoluzione piu' bassa. Il massimo di
                // 5 livelli evita di ingrandire un quadratino senza dettagli.
                boolean fallback = drawCachedParent(canvas, dest, z, ix, y);
                if (!fallback && lastMapFrame == null) {
                    shapePaint.setColor(darkMode ? Color.rgb(43, 58, 74) : Color.rgb(215, 226, 219));
                    canvas.drawRect(dest, shapePaint);
                }
                double dx = px + edge/2d - getWidth()/2d;
                double dy = py + edge/2d - getHeight()/2d;
                need.add(new Needed(key,z,ix,y,dx*dx+dy*dy));
            }
        }
        tilePaint.setColorFilter(null);
        visibleKeys = wanted; // Solo le tile effettivamente visibili possono essere scaricate.
        discardObsoleteTasks(wanted);
        Collections.sort(need, (a,b) -> Double.compare(a.distance,b.distance));
        for (Needed item : need) queueTile(item);

        // Memorizza una vista completa soltanto dopo il caricamento, e non
        // durante il gesto: niente readback GPU e niente allocazioni a 60 fps.
        if (complete && !fingerDown && scroller.isFinished() && needsNewFrame()) {
            captureFrame(z,edge,left,top,startX,endX,startY,endY,count);
        }
        drawSelection(canvas,left,top);
    }

    private boolean isUsable(Bitmap b) { return b != null && !b.isRecycled(); }
    private boolean drawCachedParent(Canvas c, RectF dest, int z, int x, int y) {
        for(int depth=1; depth<=5 && z-depth>=2; depth++) {
            Bitmap parent=memory.get((z-depth)+"/"+(x>>depth)+"/"+(y>>depth));
            if (!isUsable(parent)) continue;
            int span=1<<depth;
            int sx=(x & (span-1))*parent.getWidth()/span;
            int sy=(y & (span-1))*parent.getHeight()/span;
            int ex=((x & (span-1))+1)*parent.getWidth()/span;
            int ey=((y & (span-1))+1)*parent.getHeight()/span;
            if(ex>sx && ey>sy) {
                c.drawBitmap(parent,new Rect(sx,sy,ex,ey),dest,tilePaint);
                return true;
            }
        }
        return false;
    }

    private void drawPreviousFrame(Canvas c) {
        if (!isUsable(lastMapFrame) || frameDark != darkMode) return;
        double ratio = Math.pow(2d,zoomLevel-frameZoom);
        if (ratio < 0.48d || ratio > 2.7d) return;
        double offsetX=lonX(frameLon)-lonX(centerLon);
        double w=world();
        if(offsetX>w/2) offsetX-=w;
        if(offsetX< -w/2) offsetX+=w;
        double offsetY=latY(frameLat)-latY(centerLat);
        double bw=lastMapFrame.getWidth()*ratio, bh=lastMapFrame.getHeight()*ratio;
        RectF where=new RectF((float)(getWidth()/2d+offsetX-bw/2),
            (float)(getHeight()/2d+offsetY-bh/2),
            (float)(getWidth()/2d+offsetX+bw/2),
            (float)(getHeight()/2d+offsetY+bh/2));
        c.drawBitmap(lastMapFrame,null,where,previewPaint);
    }
    private boolean needsNewFrame() {
        if (!isUsable(lastMapFrame) || lastMapFrame.getWidth()!=getWidth() || lastMapFrame.getHeight()!=getHeight()) return true;
        if (frameDark!=darkMode || Math.abs(frameZoom-zoomLevel)>0.10) return true;
        return System.currentTimeMillis()-frameTime>700 &&
            (Math.abs(lonX(frameLon)-lonX(centerLon))>90 || Math.abs(latY(frameLat)-latY(centerLat))>90);
    }
    private void captureFrame(int z,double edge,double left,double top,int startX,int endX,int startY,int endY,int count) {
        try {
            Bitmap shot=Bitmap.createBitmap(getWidth(),getHeight(),Bitmap.Config.RGB_565);
            Canvas c=new Canvas(shot);
            c.drawColor(darkMode ? Color.rgb(36,49,63) : Color.rgb(225,231,225));
            tilePaint.setColorFilter(darkMode ? nightFilter : null);
            for(int x=startX;x<=endX;x++) for(int y=startY;y<=endY;y++) {
                if(y<0 || y>=count) continue;
                Bitmap bmp=memory.get(z+"/"+Math.floorMod(x,count)+"/"+y);
                if (!isUsable(bmp)) continue;
                float px=(float)(x*edge-left),py=(float)(y*edge-top);
                c.drawBitmap(bmp,null,new RectF(px,py,(float)(px+edge+0.5),(float)(py+edge+0.5)),tilePaint);
            }
            tilePaint.setColorFilter(null);
            if(lastMapFrame!=null) lastMapFrame.recycle();
            lastMapFrame=shot;
            frameLat=centerLat;frameLon=centerLon;frameZoom=zoomLevel;
            frameDark=darkMode;frameTime=System.currentTimeMillis();
        } catch (OutOfMemoryError ignored) { clearFrame(); }
    }
    private void clearFrame() {
        if(lastMapFrame!=null) {lastMapFrame.recycle();lastMapFrame=null;}
    }
    private void drawSelection(Canvas c,double left,double top) {
        double px=lonX(selectedLon)-left;
        if(px>getWidth()+32) px-=world();
        if(px< -32) px+=world();
        float x=(float)px,y=(float)(latY(selectedLat)-top);
        shapePaint.setColor(Color.argb(60,12,16,27)); c.drawCircle(x,y,27,shapePaint);
        shapePaint.setColor(Color.WHITE);c.drawCircle(x,y,14,shapePaint);
        shapePaint.setColor(Color.rgb(12,178,151));c.drawCircle(x,y,10,shapePaint);
        shapePaint.setColor(Color.WHITE);c.drawCircle(x,y,3,shapePaint);
    }

    private void discardObsoleteTasks(Set<String> wanted) {
        // Le richieste gia' in esecuzione possono terminare; le altre non
        // devono ritardare la mappa quando il dito si muove rapidamente.
        for(Runnable r : io.getQueue().toArray(new Runnable[0])) {
            TileTask task=(TileTask)r;
            if(!wanted.contains(task.key) && io.getQueue().remove(task))
                inflight.remove(task.key,task);
        }
    }
    private void queueTile(Needed needed) {
        TileTask t=new TileTask(needed.key,needed.z,needed.x,needed.y);
        if(inflight.putIfAbsent(needed.key,t)!=null) return;
        try { io.execute(t); }
        catch(RejectedExecutionException e) {inflight.remove(needed.key,t);}
    }
    private final class TileTask implements Runnable {
        final String key;
        final int z,x,y;
        TileTask(String key,int z,int x,int y){this.key=key;this.z=z;this.x=x;this.y=y;}
        @Override public void run() {
            try {
                if (!visibleKeys.contains(key) || Thread.currentThread().isInterrupted()) return;
                File file=new File(tileCache,key+".png");
                Bitmap cached=file.isFile()?BitmapFactory.decodeFile(file.getAbsolutePath()):null;
                long age=file.isFile()?System.currentTimeMillis()-file.lastModified():Long.MAX_VALUE;
                if (cached!=null) publish(key,cached);
                if (cached!=null && age>=0 && age<7L*86400000L) return;
                if (!visibleKeys.contains(key) || Thread.currentThread().isInterrupted()) return;
                HttpURLConnection connection=(HttpURLConnection)new URL(
                    "https://tile.openstreetmap.org/"+z+"/"+x+"/"+y+".png").openConnection();
                connection.setRequestProperty("User-Agent", "LocationLab/0.4 (Android; https://github.com/leocascione92-svg/leocasc)");
                connection.setConnectTimeout(4500);
                connection.setReadTimeout(6500);
                if(file.isFile()) connection.setIfModifiedSince(file.lastModified());
                try {
                    int status=connection.getResponseCode();
                    if(status==HttpURLConnection.HTTP_NOT_MODIFIED) {
                        file.setLastModified(System.currentTimeMillis());
                    } else if(status==HttpURLConnection.HTTP_OK) {
                        byte[] raw;
                        try(InputStream in=connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                            byte[] buf=new byte[8192];int count;
                            while((count=in.read(buf))!=-1) {
                                out.write(buf,0,count);
                                if(out.size()>2_000_000) return;
                            }
                            raw=out.toByteArray();
                        }
                        Bitmap fresh=BitmapFactory.decodeByteArray(raw,0,raw.length);
                        if(fresh!=null) {
                            file.getParentFile().mkdirs();
                            try(FileOutputStream out=new FileOutputStream(file)){out.write(raw);}
                            publish(key,fresh);
                        }
                    }
                } finally {connection.disconnect();}
            } catch(Exception ignored) { /* tiles precedentemente viste restano visibili */ }
            finally {inflight.remove(key,this);}
        }
    }
    private void publish(String key, Bitmap bmp) {
        main.post(() -> {
            if(isAttachedToWindow() && !bmp.isRecycled()) {
                memory.put(key,bmp);
                if(visibleKeys.contains(key)) postInvalidateOnAnimation();
            }
        });
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        detector.onTouchEvent(event);
        switch(event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                fingerDown=true;scroller.forceFinished(true);
                if(velocity!=null) velocity.recycle();
                velocity=VelocityTracker.obtain();velocity.addMovement(event);
                downX=prevX=event.getX();downY=prevY=event.getY();
                dragged=false;multiTouch=false;
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                multiTouch=true;dragged=true;
                return true;
            case MotionEvent.ACTION_MOVE:
                if(velocity!=null)velocity.addMovement(event);
                if(event.getPointerCount()>1 || detector.isInProgress()) {dragged=true;return true;}
                float xx=event.getX(),yy=event.getY();
                if(Math.hypot(xx-downX,yy-downY)>10*getResources().getDisplayMetrics().density) dragged=true;
                if(dragged) pan(xx-prevX,yy-prevY);
                prevX=xx;prevY=yy;
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                dragged=true;multiTouch=true;
                // Terminato il pinch, il dito rimasto continua a trascinare la
                // stessa mappa senza salto o blocco del pan.
                int other=event.getActionIndex()==0?1:0;
                if(other<event.getPointerCount()) {
                    prevX=downX=event.getX(other);
                    prevY=downY=event.getY(other);
                }
                return true;
            case MotionEvent.ACTION_UP:
                fingerDown=false;
                if(velocity!=null) {
                    velocity.addMovement(event);
                    if(dragged && !multiTouch) {
                        velocity.computeCurrentVelocity(1000);
                        int vx=(int)velocity.getXVelocity(),vy=(int)velocity.getYVelocity();
                        if(Math.abs(vx)>350 || Math.abs(vy)>350) {
                            scrollerX=0;scrollerY=0;
                            scroller.fling(0,0,vx,vy,Integer.MIN_VALUE,Integer.MAX_VALUE,Integer.MIN_VALUE,Integer.MAX_VALUE);
                        }
                    }
                    velocity.recycle();velocity=null;
                }
                if (!dragged && !multiTouch && !detector.isInProgress()) {
                    double lat=yLat(latY(centerLat)+event.getY()-getHeight()/2d);
                    double lon=xLon(lonX(centerLon)+event.getX()-getWidth()/2d);
                    setPosition(lat,lon,false);
                    if(listener!=null)listener.onSelected(selectedLat,selectedLon);
                }
                postInvalidateOnAnimation();
                performClick();return true;
            case MotionEvent.ACTION_CANCEL:
                fingerDown=false;
                if(velocity!=null){velocity.recycle();velocity=null;}
                postInvalidateOnAnimation();
                return true;
            default:return true;
        }
    }
    @Override public void computeScroll() {
        if(scroller.computeScrollOffset()) {
            int nx=scroller.getCurrX(),ny=scroller.getCurrY();
            pan(nx-scrollerX,ny-scrollerY);
            scrollerX=nx;scrollerY=ny;
            postInvalidateOnAnimation();
        }
    }
    @Override public boolean performClick(){super.performClick();return true;}
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);clearFrame();}
    @Override protected void onDetachedFromWindow(){
        super.onDetachedFromWindow();scroller.forceFinished(true);io.shutdownNow();clearFrame();
    }
}
