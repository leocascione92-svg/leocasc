package it.locationlab.app;

import android.content.Context;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/** Mappa OpenStreetMap leggera, senza librerie, annunci o tracciatori. */
public final class TileMapView extends View {
    public interface OnSelectedListener { void onSelected(double latitude, double longitude); }
    private OnSelectedListener listener;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final LruCache<String, Bitmap> memory = new LruCache<String, Bitmap>(12 * 1024) {
        @Override protected int sizeOf(String key, Bitmap bitmap) { return bitmap.getByteCount() / 1024; }
    };
    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private final Set<String> inflight = Collections.synchronizedSet(new HashSet<>());
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ScaleGestureDetector scale;
    private double centerLat = 41.893, centerLon = 12.483;
    private double selectedLat = centerLat, selectedLon = centerLon;
    private int zoom = 13;
    private float downX, downY, previousX, previousY;
    private boolean dragged;
    private float pinch = 1f;
    private final File tileCache;

    public TileMapView(Context context) {
        super(context);
        tileCache = new File(context.getCacheDir(), "osm-tiles");
        scale = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                pinch *= detector.getScaleFactor();
                if (pinch > 1.55f) { zoomBy(1); pinch = 1f; }
                if (pinch < 0.65f) { zoomBy(-1); pinch = 1f; }
                return true;
            }
        });
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }
    public void setOnSelectedListener(OnSelectedListener l) { listener = l; }
    public void setPosition(double latitude, double longitude, boolean recentre) {
        selectedLat = clamp(latitude, -85.0511, 85.0511);
        selectedLon = normalizeLon(longitude);
        if (recentre) { centerLat = selectedLat; centerLon = selectedLon; }
        invalidate();
    }
    public void zoomBy(int delta) { zoom = (int) clamp(zoom + delta, 2, 18); invalidate(); }

    private static double clamp(double n, double min, double max) { return Math.max(min, Math.min(max, n)); }
    private static double normalizeLon(double lon) { return (lon + 540) % 360 - 180; }
    private double world() { return 256d * (1 << zoom); }
    private double lonX(double lon) { return (lon + 180d) / 360d * world(); }
    private double latY(double lat) {
        double r = Math.toRadians(clamp(lat, -85.0511, 85.0511));
        return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * world();
    }
    private double xLon(double x) { return normalizeLon(x / world() * 360 - 180); }
    private double yLat(double y) { return Math.toDegrees(Math.atan(Math.sinh(Math.PI * (1 - 2 * y / world())))); }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(Color.rgb(232, 237, 235));
        double left = lonX(centerLon) - getWidth()/2d;
        double top = latY(centerLat) - getHeight()/2d;
        int startX = (int) Math.floor(left / 256d), endX = (int) Math.floor((left + getWidth())/256d);
        int startY = (int) Math.floor(top / 256d), endY = (int) Math.floor((top + getHeight())/256d);
        int count = 1 << zoom;
        for (int x = startX; x <= endX; x++) for (int y = startY; y <= endY; y++) {
            if (y < 0 || y >= count) continue;
            int ix = Math.floorMod(x, count);
            int tileX = (int) Math.round(x * 256d - left);
            int tileY = (int) Math.round(y * 256d - top);
            String key = zoom + "/" + ix + "/" + y;
            Bitmap bmp = memory.get(key);
            if (bmp != null && !bmp.isRecycled()) {
                c.drawBitmap(bmp, null, new Rect(tileX, tileY, tileX + 257, tileY + 257), paint);
            } else {
                paint.setColor(Color.rgb(219, 229, 225));
                c.drawRect(tileX, tileY, tileX + 256, tileY + 256, paint);
                queueTile(key, zoom, ix, y);
            }
        }
        // Segnaposto della coordinata selezionata.
        double px = lonX(selectedLon) - left;
        double py = latY(selectedLat) - top;
        if (px - getWidth() > 0) px -= world();
        else if (px < -getWidth()) px += world();
        float xx = (float) px, yy = (float) py;
        paint.setColor(Color.argb(45, 16, 53, 85));
        c.drawCircle(xx, yy, 21, paint);
        paint.setColor(Color.WHITE);
        c.drawCircle(xx, yy, 12, paint);
        paint.setColor(Color.rgb(39, 116, 179));
        c.drawCircle(xx, yy, 9, paint);
    }

    private void queueTile(String key, int z, int x, int y) {
        if (!inflight.add(key)) return;
        io.execute(() -> {
            try {
                File file = new File(tileCache, key + ".png");
                Bitmap bitmap = null;
                // Cache persistente di almeno 7 giorni; non eseguiamo scaricamenti massivi.
                if (file.isFile() && System.currentTimeMillis() - file.lastModified() < 7L*24*60*60*1000) {
                    bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                }
                if (bitmap == null) {
                    URL url = new URL("https://tile.openstreetmap.org/" + z + "/" + x + "/" + y + ".png");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestProperty("User-Agent", "LocationLab/0.1 (it.locationlab.app; personal Android map)");
                    connection.setConnectTimeout(6000);
                    connection.setReadTimeout(8000);
                    try {
                        if (connection.getResponseCode() == 200) {
                            try (InputStream stream = connection.getInputStream(); ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                                byte[] buffer = new byte[4096]; int n;
                                while ((n = stream.read(buffer)) != -1) bytes.write(buffer, 0, n);
                                byte[] data = bytes.toByteArray();
                                bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                                if (bitmap != null) {
                                    file.getParentFile().mkdirs();
                                    try (FileOutputStream out = new FileOutputStream(file)) { out.write(data); }
                                }
                            }
                        }
                    } finally { connection.disconnect(); }
                }
                final Bitmap result = bitmap;
                if (result != null) main.post(() -> { memory.put(key, result); invalidate(); });
            } catch (Exception ignored) { /* map gracefully handles offline usage */ }
            finally { inflight.remove(key); }
        });
    }
    @Override public boolean onTouchEvent(MotionEvent ev) {
        scale.onTouchEvent(ev);
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = previousX = ev.getX(); downY = previousY = ev.getY(); dragged = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (ev.getPointerCount() > 1) { dragged = true; return true; }
                float x = ev.getX(), y = ev.getY();
                if (Math.hypot(x-downX, y-downY) > 12 * getResources().getDisplayMetrics().density) dragged = true;
                if (dragged) {
                    double worldX = lonX(centerLon) - (x - previousX);
                    double worldY = latY(centerLat) - (y - previousY);
                    centerLon = xLon(worldX);
                    centerLat = yLat(clamp(worldY, 0, world()));
                    invalidate();
                }
                previousX = x; previousY = y;
                return true;
            case MotionEvent.ACTION_UP:
                if (!dragged && !scale.isInProgress()) {
                    double lat = yLat(latY(centerLat) + ev.getY() - getHeight()/2d);
                    double lon = xLon(lonX(centerLon) + ev.getX() - getWidth()/2d);
                    setPosition(lat, lon, false);
                    if (listener != null) listener.onSelected(selectedLat, selectedLon);
                }
                performClick(); return true;
            case MotionEvent.ACTION_CANCEL: return true;
            default: return true;
        }
    }
    @Override public boolean performClick() { super.performClick(); return true; }
    @Override protected void onDetachedFromWindow() { super.onDetachedFromWindow(); io.shutdownNow(); }
}
