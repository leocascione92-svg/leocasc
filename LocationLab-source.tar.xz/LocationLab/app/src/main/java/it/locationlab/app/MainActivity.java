package it.locationlab.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationListener;
import android.os.Looper;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;
import java.util.concurrent.*;

/** App Android ad-free sviluppata indipendentemente. */
public final class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(25, 59, 100);
    private static final int CYAN = Color.rgb(40, 144, 191);
    private static final int INK = Color.rgb(36, 52, 70);
    private static final int PERMISSIONS = 51;
    private static final int PERMISSION_RECENTER = 53;
    private static final int DOCUMENT_EXPORT = 601;
    private static final int DOCUMENT_IMPORT = 602;
    private static final int MAX_FAVORITES = 300;
    private boolean awaitingDestination = false;
    private TextView hintView;
    private final Runnable stateMonitor = new Runnable() {
        @Override public void run() {
            if (map != null) {
                android.content.SharedPreferences sim = getSharedPreferences("state", MODE_PRIVATE);
                boolean running = sim.getBoolean("running", false);
                boolean paused = sim.getBoolean("paused", false);
                boolean hasLive = sim.contains("liveLat") && sim.contains("liveLon");
                if (hasLive) {
                    double lat = Double.longBitsToDouble(sim.getLong("liveLat", 0L));
                    double lon = Double.longBitsToDouble(sim.getLong("liveLon", 0L));
                    if (validCoordinates(lat,lon)) map.setLivePosition(lat,lon,running||paused);
                    else map.setLivePosition(0,0,false);
                } else map.setLivePosition(0,0,false);
                refreshSimulationState();
                if (running && sim.getBoolean("routeRunning",false))
                    status.setText("●  " + sim.getInt("routePercent",0) + "%");
                if (sim.getBoolean("routeCompleted",false)) {
                    sim.edit().remove("routeCompleted").apply();
                    message("Percorso completato. Simulazione terminata.");
                }
            }
            mainHandler.postDelayed(this,1000L);
        }
    };
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private LocationManager locationManager;
    private LocationListener locationListener;
    private Runnable locationTimeout;

    private TileMapView map;
    private TextView position, status;
    private double latitude = 41.893, longitude = 12.483;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10, 14, 22));
        getWindow().setNavigationBarColor(Color.rgb(10, 14, 22));
        getWindow().getDecorView().setSystemUiVisibility(0);
        latitude = Double.longBitsToDouble(getPreferences(MODE_PRIVATE).getLong("latitude", Double.doubleToRawLongBits(latitude)));
        longitude = Double.longBitsToDouble(getPreferences(MODE_PRIVATE).getLong("longitude", Double.doubleToRawLongBits(longitude)));
        if (!Double.isFinite(latitude) || latitude < -85 || latitude > 85) latitude = 41.893;
        if (!Double.isFinite(longitude) || longitude < -180 || longitude > 180) longitude = 12.483;
        buildUi();
        updatePosition();
    }

    private static final int BACKGROUND = Color.rgb(10, 14, 22);
    private static final int SURFACE = Color.rgb(18, 26, 39);
    private static final int SURFACE_HIGH = Color.rgb(30, 42, 58);
    private static final int TEXT_PRIMARY = Color.rgb(239, 244, 250);
    private static final int TEXT_SECONDARY = Color.rgb(145, 163, 183);
    private static final int ACCENT = Color.rgb(81, 218, 188);
    private TextView primaryAction;

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BACKGROUND);
        setContentView(root);
        // Android 15/16 applica edge-to-edge obbligatorio: lo spazio dei controlli
        // viene aggiustato usando gli inset reali delle barre di sistema.
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                view.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets;
            });
            root.requestApplyInsets();
        }

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(19), 0, dp(12), 0);
        top.setBackgroundColor(BACKGROUND);
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(60)));
        TextView logo = label("◉", 27, ACCENT, true);
        top.addView(logo, new LinearLayout.LayoutParams(dp(38), -1));
        TextView title = label("LocationLab", 21, TEXT_PRIMARY, true);
        top.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        status = label("●  Pronto", 12, ACCENT, true);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(11), 0, dp(11), 0);
        status.setBackground(round(SURFACE_HIGH, 100));
        top.addView(status, new LinearLayout.LayoutParams(-2, dp(32)));
        TextView menu = label("⋮", 27, TEXT_PRIMARY, false);
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription("Altre opzioni");
        top.addView(menu, new LinearLayout.LayoutParams(dp(42), dp(48)));
        menu.setOnClickListener(v -> showMenu(menu));

        FrameLayout mapArea = new FrameLayout(this);
        root.addView(mapArea, new LinearLayout.LayoutParams(-1, 0, 1));
        map = new TileMapView(this);
        map.setDarkMode(getPreferences(MODE_PRIVATE).getBoolean("darkMap", true));
        map.setPosition(latitude, longitude, true);
        map.setOnSelectedListener((lat, lon) -> {
            latitude = lat; longitude = lon; updatePosition();
            if (awaitingDestination) {
                awaitingDestination = false;
                configureRouteArrival(lat,lon);
            }
        });
        restoreRouteOverlay();
        mapArea.addView(map, new FrameLayout.LayoutParams(-1, -1));

        TextView search = label("⌕   Cerca un indirizzo o un luogo", 14, TEXT_SECONDARY, false);
        search.setPadding(dp(17), 0, dp(14), 0);
        search.setBackground(round(SURFACE, 18));
        search.setElevation(dp(4));
        search.setContentDescription("Cerca un luogo sulla mappa");
        FrameLayout.LayoutParams searchLp = new FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP);
        searchLp.setMargins(dp(16), dp(16), dp(75), 0);
        mapArea.addView(search, searchLp);
        search.setOnClickListener(v -> search());

        LinearLayout zooms = new LinearLayout(this);
        zooms.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams zoomLp = new FrameLayout.LayoutParams(dp(47), -2, Gravity.TOP | Gravity.RIGHT);
        zoomLp.setMargins(0, dp(18), dp(16), 0);
        mapArea.addView(zooms, zoomLp);
        TextView zoomIn = squareAction("+", () -> map.zoomBy(1));
        TextView zoomOut = squareAction("−", () -> map.zoomBy(-1));
        zooms.addView(zoomIn, new LinearLayout.LayoutParams(-1, dp(46)));
        LinearLayout.LayoutParams minusParams = new LinearLayout.LayoutParams(-1, dp(46));
        minusParams.topMargin = dp(7);
        zooms.addView(zoomOut, minusParams);
        TextView recenter = squareAction("◎", this::recenterOnDevice);
        recenter.setTextSize(25);
        recenter.setContentDescription("Torna alla posizione reale del telefono");
        LinearLayout.LayoutParams recenterParams = new LinearLayout.LayoutParams(-1, dp(46));
        recenterParams.topMargin = dp(15);
        zooms.addView(recenter, recenterParams);

        TextView attribution = label("© OpenStreetMap contributors", 10, TEXT_PRIMARY, false);
        attribution.setPadding(dp(9), dp(5), dp(9), dp(5));
        attribution.setBackground(round(Color.rgb(33, 44, 58), 8));
        FrameLayout.LayoutParams attr = new FrameLayout.LayoutParams(-2, -2, Gravity.LEFT | Gravity.BOTTOM);
        attr.setMargins(dp(12), 0, 0, dp(10));
        mapArea.addView(attribution, attr);

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(20), dp(10), dp(20), dp(16));
        GradientDrawable surface = new GradientDrawable();
        surface.setColor(SURFACE);
        surface.setCornerRadii(new float[]{dp(23),dp(23),dp(23),dp(23),0,0,0,0});
        sheet.setBackground(surface);
        root.addView(sheet, new LinearLayout.LayoutParams(-1, -2));

        TextView handle = label("", 2, TEXT_SECONDARY, false);
        handle.setBackground(round(Color.rgb(78, 95, 112), 100));
        LinearLayout.LayoutParams handleLp = new LinearLayout.LayoutParams(dp(38), dp(4));
        handleLp.gravity = Gravity.CENTER_HORIZONTAL;
        handleLp.bottomMargin = dp(15);
        sheet.addView(handle, handleLp);

        LinearLayout pointRow = new LinearLayout(this);
        pointRow.setGravity(Gravity.CENTER_VERTICAL);
        sheet.addView(pointRow, new LinearLayout.LayoutParams(-1, dp(35)));
        TextView pointIcon = label("⌖", 23, ACCENT, true);
        pointRow.addView(pointIcon, new LinearLayout.LayoutParams(dp(35), -1));
        TextView pointLabel = label("POSIZIONE SELEZIONATA", 11, TEXT_SECONDARY, true);
        pointRow.addView(pointLabel, new LinearLayout.LayoutParams(0, -1, 1));
        TextView save = label("☆  Salva", 13, ACCENT, true);
        save.setGravity(Gravity.CENTER);
        save.setPadding(dp(12), 0, dp(12), 0);
        save.setBackground(round(SURFACE_HIGH, 13));
        pointRow.addView(save, new LinearLayout.LayoutParams(-2, dp(35)));
        save.setOnClickListener(v -> saveFavorite());

        position = label("", 20, TEXT_PRIMARY, true);
        position.setTypeface(Typeface.create("monospace", Typeface.BOLD));
        position.setPadding(dp(3), dp(5), 0, dp(12));
        position.setContentDescription("Coordinate selezionate. Tocca per modificarle");
        sheet.addView(position, new LinearLayout.LayoutParams(-1, -2));
        position.setOnClickListener(v -> enterCoordinates());

        LinearLayout tools = new LinearLayout(this);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        sheet.addView(tools, new LinearLayout.LayoutParams(-1, dp(43)));
        addTextAction(tools, "✎  Coordinate", v -> enterCoordinates());
        addTextAction(tools, "↗  Maps", v -> openInMaps());
        addTextAction(tools, "☆  Preferiti", v -> showEntries("favorites", "Preferiti"));
        addTextAction(tools, "⌁  Percorso", v -> beginRoute());

        primaryAction = label("▶  Avvia simulazione", 16, BACKGROUND, true);
        primaryAction.setGravity(Gravity.CENTER);
        primaryAction.setBackground(round(ACCENT, 16));
        primaryAction.setContentDescription("Avvia o arresta il GPS simulato");
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, dp(54));
        actionLp.topMargin = dp(8);
        sheet.addView(primaryAction, actionLp);
        primaryAction.setOnClickListener(v -> {
            boolean running = getSharedPreferences("state", MODE_PRIVATE).getBoolean("running", false);
            boolean paused = getSharedPreferences("state", MODE_PRIVATE).getBoolean("paused", false);
            if (paused) resumeSimulation();
            else if (running) stopSimulation();
            else startSimulation();
            mainHandler.postDelayed(this::refreshSimulationState, 400L);
        });
        TextView hint = label("Tocca la mappa per scegliere un punto · Pizzica per ingrandire", 11, TEXT_SECONDARY, false);
        hint.setGravity(Gravity.CENTER);
        hintView = hint;
        updateRouteHint();
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, dp(25));
        hintLp.topMargin = dp(5);
        sheet.addView(hint, hintLp);
    }

    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }
    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(false);
        return t;
    }
    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radiusDp));
        return bg;
    }
    private TextView squareAction(String value, Runnable action) {
        TextView v = label(value, 26, TEXT_PRIMARY, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(round(SURFACE, 14));
        v.setElevation(dp(3));
        v.setOnClickListener(w -> action.run());
        v.setContentDescription(value.equals("+") ? "Ingrandisci mappa" : "Riduci mappa");
        return v;
    }
    private void addTextAction(LinearLayout row, String text, View.OnClickListener action) {
        TextView view = label(text, 12, TEXT_SECONDARY, true);
        view.setGravity(Gravity.CENTER);
        row.addView(view, new LinearLayout.LayoutParams(0, -1, 1f));
        view.setOnClickListener(action);
    }
    private void showMenu(View anchor) {
        PopupMenu pop = new PopupMenu(this, anchor);
        pop.getMenu().add("Cerca un luogo").setOnMenuItemClickListener(i -> {search(); return true;});
        pop.getMenu().add("Inserisci coordinate").setOnMenuItemClickListener(i -> {enterCoordinates(); return true;});
        pop.getMenu().add("Preferiti").setOnMenuItemClickListener(i -> {showEntries("favorites", "Preferiti"); return true;});
        pop.getMenu().add("Cronologia").setOnMenuItemClickListener(i -> {showEntries("history", "Cronologia"); return true;});
        pop.getMenu().add("Nuovo percorso (partenza qui)").setOnMenuItemClickListener(i -> {beginRoute(); return true;});
        if (getPreferences(MODE_PRIVATE).getBoolean("route_enabled",false))
            pop.getMenu().add("Rimuovi percorso").setOnMenuItemClickListener(i -> {removeRoute(); return true;});
        pop.getMenu().add("Parametri GPS e oscillazione").setOnMenuItemClickListener(i -> {showGpsSettings(); return true;});
        pop.getMenu().add("Unità di misura").setOnMenuItemClickListener(i -> {showUnits(); return true;});
        if (getSharedPreferences("state",MODE_PRIVATE).getBoolean("running",false))
            pop.getMenu().add("Pausa la simulazione").setOnMenuItemClickListener(i -> {pauseSimulation(); return true;});
        pop.getMenu().add("Apri posizione in Google Maps").setOnMenuItemClickListener(i -> {openInMaps(); return true;});
        pop.getMenu().add("Esporta preferiti (JSON)").setOnMenuItemClickListener(i -> {exportFavorites(); return true;});
        pop.getMenu().add("Importa preferiti (JSON)").setOnMenuItemClickListener(i -> {importFavorites(); return true;});
        pop.getMenu().add("Torna alla posizione reale").setOnMenuItemClickListener(i -> {recenterOnDevice(); return true;});
        pop.getMenu().add(map.isDarkMode() ? "Mappa chiara" : "Mappa scura").setOnMenuItemClickListener(i -> {
            boolean dark = !map.isDarkMode();
            map.setDarkMode(dark);
            getPreferences(MODE_PRIVATE).edit().putBoolean("darkMap", dark).apply();
            return true;
        });
        pop.getMenu().add("Opzioni sviluppatore · Posizione fittizia").setOnMenuItemClickListener(i -> {openDevSettings();return true;});
        pop.show();
    }
    private void refreshSimulationState() {
        if (status == null || primaryAction == null) return;
        android.content.SharedPreferences s = getSharedPreferences("state", MODE_PRIVATE);
        boolean running = s.getBoolean("running", false);
        boolean paused = s.getBoolean("paused", false);
        status.setText(paused ? "●  Pausa" : running ? "●  Attivo" : "●  Pronto");
        status.setTextColor(running ? ACCENT : TEXT_SECONDARY);
        boolean route = getPreferences(MODE_PRIVATE).getBoolean("route_enabled", false);
        primaryAction.setText(paused ? "▶  Riprendi simulazione" :
            running ? "■  Termina simulazione" : route ? "▶  Avvia percorso" : "▶  Avvia simulazione");
        primaryAction.setTextColor(running ? TEXT_PRIMARY : BACKGROUND);
        primaryAction.setBackground(round(running ? Color.rgb(128, 52, 62) : ACCENT, 16));
    }

    private void updatePosition() {
        position.setText(String.format(Locale.US, "%.6f°, %.6f°", latitude, longitude));
        getPreferences(MODE_PRIVATE).edit().putLong("latitude", Double.doubleToRawLongBits(latitude))
            .putLong("longitude", Double.doubleToRawLongBits(longitude)).apply();
    }
    private android.content.SharedPreferences pref() { return getPreferences(MODE_PRIVATE); }
    private boolean mph() { return pref().getBoolean("units_mph", false); }
    private boolean feet() { return pref().getBoolean("units_feet", false); }
    private String speedUnit(){return mph()?"mph":"km/h";}
    private double speedDisplay(double mps){return mps*(mph()?2.2369362921:3.6);}
    private double speedToMps(double display){return display/(mph()?2.2369362921:3.6);}
    private static double storedCoord(android.content.SharedPreferences p,String key,double fallback){
        return Double.longBitsToDouble(p.getLong(key,Double.doubleToRawLongBits(fallback)));
    }
    private static void putDouble(android.content.SharedPreferences.Editor e,String key,double value){
        e.putLong(key,Double.doubleToRawLongBits(value));
    }
    private void beginRoute() {
        if (getSharedPreferences("state",MODE_PRIVATE).getBoolean("running",false) ||
            getSharedPreferences("state",MODE_PRIVATE).getBoolean("paused",false)) {
            message("Termina la simulazione prima di preparare un nuovo percorso"); return;
        }
        final double startA=latitude,startB=longitude;
        new AlertDialog.Builder(this).setTitle("Nuovo percorso")
            .setMessage("La partenza sarà il punto selezionato. Tocca poi il punto di arrivo sulla mappa. Il percorso sarà una linea diretta, non stradale.")
            .setNegativeButton("Annulla",null)
            .setPositiveButton("Scegli arrivo",(d,w)->{
                routeDraftLat=startA;routeDraftLon=startB;
                awaitingDestination=true;
                updateRouteHint();
                message("Tocca sulla mappa il punto di arrivo");
            }).show();
    }
    private double routeDraftLat,routeDraftLon;
    private void configureRouteArrival(double endLat,double endLon) {
        double distance=MockLocationService.distanceMeters(routeDraftLat,routeDraftLon,endLat,endLon);
        if (distance < 1) {message("Scegli un arrivo diverso dalla partenza");updateRouteHint();return;}
        EditText field=new EditText(this);
        field.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        double previous=speedDisplay(pref().getFloat("route_speed_mps",(float)(35/3.6)));
        field.setText(String.format(Locale.US,"%.1f",previous));
        field.setSelectAllOnFocus(true);
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22),dp(8),dp(22),0);
        TextView label=label(String.format(Locale.ITALIAN,"Distanza diretta: %.2f km · Nessun calcolo stradale",distance/1000d),13,TEXT_SECONDARY,false);
        content.addView(label,new LinearLayout.LayoutParams(-1,dp(42)));
        content.addView(field,new LinearLayout.LayoutParams(-1,dp(52)));
        AlertDialog dlg=new AlertDialog.Builder(this)
            .setTitle("Velocità percorso ("+speedUnit()+")")
            .setView(content).setNegativeButton("Annulla",(d,w)->updateRouteHint())
            .setPositiveButton("Prepara percorso",null).create();
        dlg.setOnShowListener(v->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view->{
            try {
                double displayed=Double.parseDouble(field.getText().toString().replace(',','.').trim());
                double mps=speedToMps(displayed);
                if(!Double.isFinite(mps)||mps<0.15||mps>100d)throw new IllegalArgumentException();
                android.content.SharedPreferences.Editor e=pref().edit();
                putDouble(e,"route_start_lat",routeDraftLat);putDouble(e,"route_start_lon",routeDraftLon);
                putDouble(e,"route_end_lat",endLat);putDouble(e,"route_end_lon",endLon);
                e.putFloat("route_speed_mps",(float)mps).putBoolean("route_enabled",true).apply();
                restoreRouteOverlay(); updateRouteHint(); refreshSimulationState(); dlg.dismiss();
            }catch(Exception ex){field.setError("Inserisci una velocità valida (0,5–360 km/h)");}
        }));
        dlg.show();
    }
    private void restoreRouteOverlay() {
        if(map==null)return;
        android.content.SharedPreferences p=pref();
        if(p.getBoolean("route_enabled",false)) {
            double a=storedCoord(p,"route_start_lat",latitude),b=storedCoord(p,"route_start_lon",longitude);
            double c=storedCoord(p,"route_end_lat",latitude),d=storedCoord(p,"route_end_lon",longitude);
            if(validCoordinates(a,b)&&validCoordinates(c,d))map.setRoutePreview(a,b,c,d);
            else map.clearRoutePreview();
        }else map.clearRoutePreview();
    }
    private void removeRoute() {
        awaitingDestination=false;
        pref().edit().putBoolean("route_enabled",false).apply();
        if(map!=null)map.clearRoutePreview();
        updateRouteHint();refreshSimulationState();message("Percorso rimosso");
    }
    private void updateRouteHint(){
        if(hintView==null)return;
        if(awaitingDestination){hintView.setText("Tocca la mappa per impostare l'arrivo del percorso");return;}
        if(pref().getBoolean("route_enabled",false)) {
            hintView.setText(String.format(Locale.ITALIAN,"Percorso diretto pronto · %.1f %s · ⋮ per rimuovere",
                speedDisplay(pref().getFloat("route_speed_mps",0f)),speedUnit()));
        }else hintView.setText("Tocca per selezionare · Pizzica per ingrandire");
    }
    private EditText settingField(LinearLayout container,String title,String value,boolean signed){
        TextView name=label(title,13,TEXT_SECONDARY,false);
        LinearLayout.LayoutParams titleLp=new LinearLayout.LayoutParams(-1,dp(27));titleLp.topMargin=dp(12);
        container.addView(name,titleLp);
        EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|
            (signed?InputType.TYPE_NUMBER_FLAG_SIGNED:0));
        input.setText(value);
        container.addView(input,new LinearLayout.LayoutParams(-1,dp(48)));
        return input;
    }
    private static double parseSetting(EditText input,double minimum,double maximum){
        double value=Double.parseDouble(input.getText().toString().replace(',','.').trim());
        if(!Double.isFinite(value)||value<minimum||value>maximum)throw new IllegalArgumentException();
        return value;
    }
    private void showGpsSettings() {
        LinearLayout container=new LinearLayout(this);container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(24),dp(4),dp(24),dp(18));
        EditText alt=settingField(container,"Altitudine ("+(feet()?"piedi":"metri")+")",
            String.format(Locale.US,"%.1f",pref().getFloat("gps_altitude_m",0f)*(feet()?3.280839895:1)),true);
        EditText accuracy=settingField(container,"Precisione dichiarata (metri)",
            String.format(Locale.US,"%.1f",pref().getFloat("gps_accuracy_m",3f)),false);
        EditText speed=settingField(container,"Velocità posizione fissa ("+speedUnit()+")",
            String.format(Locale.US,"%.1f",speedDisplay(pref().getFloat("gps_speed_mps",0f))),false);
        EditText jitter=settingField(container,"Oscillazione massima (metri; 0 = disattiva)",
            String.format(Locale.US,"%.1f",pref().getFloat("gps_jitter_m",0f)),false);
        ScrollView scroll=new ScrollView(this);scroll.addView(container);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Parametri GPS")
            .setMessage("I valori sono applicati alla prossima simulazione. L'oscillazione resta entro il raggio indicato.")
            .setView(scroll).setNegativeButton("Annulla",null).setPositiveButton("Salva",null).create();
        dlg.setOnShowListener(v->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view->{
            try {
                double a=parseSetting(alt,feet()?-3280:-1000,feet()?39370:12000)/(feet()?3.280839895:1);
                double ac=parseSetting(accuracy,1,10000);
                double sp=speedToMps(parseSetting(speed,0,mph()?223:360));
                double ji=parseSetting(jitter,0,200);
                pref().edit().putFloat("gps_altitude_m",(float)a)
                    .putFloat("gps_accuracy_m",(float)ac).putFloat("gps_speed_mps",(float)sp)
                    .putFloat("gps_jitter_m",(float)ji).apply();
                message("Impostazioni GPS salvate");dlg.dismiss();
            }catch(Exception ex){message("Controlla i numeri: altitudine, precisione, velocità, oscillazione");}
        }));dlg.show();
    }
    private void showUnits() {
        boolean[] checked={mph(),feet()};
        new AlertDialog.Builder(this).setTitle("Unità di misura")
            .setMultiChoiceItems(new String[]{"Velocità in mph (anziché km/h)","Altitudine in piedi (anziché metri)"},checked,
                (d,which,isChecked)->checked[which]=isChecked)
            .setNegativeButton("Annulla",null)
            .setPositiveButton("Applica",(d,w)->{
                pref().edit().putBoolean("units_mph",checked[0]).putBoolean("units_feet",checked[1]).apply();
                updateRouteHint();message("Unità di misura aggiornate");
            }).show();
    }
    private void pauseSimulation(){
        Intent i=new Intent(this,MockLocationService.class).setAction(MockLocationService.ACTION_PAUSE);
        try{startService(i);mainHandler.postDelayed(this::refreshSimulationState,350L);}
        catch(Exception ex){message("Impossibile mettere in pausa");}
    }
    private void resumeSimulation(){
        Intent i=new Intent(this,MockLocationService.class).setAction(MockLocationService.ACTION_RESUME);
        try{startService(i);mainHandler.postDelayed(this::refreshSimulationState,350L);}
        catch(Exception ex){message("Impossibile riprendere");}
    }

    private void select(double lat, double lon) {
        if (!Double.isFinite(lat) || !Double.isFinite(lon) || lat < -85 || lat > 85 || lon < -180 || lon > 180) {
            message("Coordinate fuori intervallo valido"); return;
        }
        latitude = lat; longitude = lon;
        map.setPosition(lat, lon, true);
        updatePosition();
    }
    private void enterCoordinates() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("41.893, 12.483");
        input.setText(String.format(Locale.US, "%.6f, %.6f", latitude, longitude));
        new AlertDialog.Builder(this).setTitle("Inserisci latitudine, longitudine")
            .setView(input).setNegativeButton("Annulla", null)
            .setPositiveButton("Vai", (d, w) -> {
                try {
                    String[] parts = input.getText().toString().trim().split("[,;\\s]+", 2);
                    if (parts.length != 2) throw new NumberFormatException();
                    select(Double.parseDouble(parts[0]), Double.parseDouble(parts[1]));
                } catch (Exception e) { message("Formato: latitudine, longitudine (con punto decimale)"); }
            }).show();
    }
    private void search() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Es. Piazza Duomo, Milano");
        new AlertDialog.Builder(this).setTitle("Cerca un indirizzo")
            .setMessage("Ricerca tramite il servizio di geocodifica del dispositivo")
            .setView(input).setNegativeButton("Annulla", null)
            .setPositiveButton("Cerca", (d, w) -> {
                String query = input.getText().toString().trim();
                if (query.length() < 3) return;
                status.setText("Ricerca…");
                worker.execute(() -> {
                    try {
                        Geocoder geocoder = new Geocoder(this, Locale.ITALIAN);
                        List<Address> results = geocoder.getFromLocationName(query, 1);
                        runOnUiThread(() -> {
                            refreshSimulationState();
                            if (results == null || results.isEmpty()) message("Nessun luogo trovato");
                            else select(results.get(0).getLatitude(), results.get(0).getLongitude());
                        });
                    } catch (Exception e) {
                        runOnUiThread(() -> { refreshSimulationState(); message("Ricerca non disponibile su questo dispositivo"); });
                    }
                });
            }).show();
    }

    private JSONArray getItems(String key) {
        try { return new JSONArray(getPreferences(MODE_PRIVATE).getString(key, "[]")); }
        catch (Exception ex) { return new JSONArray(); }
    }
    private void putItems(String key, JSONArray list) {
        getPreferences(MODE_PRIVATE).edit().putString(key, list.toString()).apply();
    }
    private void remember(String key, String name) {
        try {
            JSONArray input = getItems(key);
            JSONArray output = new JSONArray();
            JSONObject record = new JSONObject();
            record.put("name", name).put("lat", latitude).put("lon", longitude);
            output.put(record);
            for (int i=0; i<input.length() && output.length() < ("favorites".equals(key) ? MAX_FAVORITES : 40); i++) {
                JSONObject previous = input.optJSONObject(i);
                if (previous == null) continue;
                if (Math.abs(previous.optDouble("lat")-latitude)<0.000001 &&
                    Math.abs(previous.optDouble("lon")-longitude)<0.000001) continue;
                output.put(previous);
            }
            putItems(key, output);
        } catch (Exception ex) { message("Impossibile salvare"); }
    }
    private LinearLayout favoriteEditor(JSONObject existing, EditText[] output){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(22),dp(6),dp(22),dp(8));
        EditText name=settingField(form,"Nome",existing!=null?existing.optString("name"):String.format(Locale.US,"Luogo %.4f, %.4f",latitude,longitude),false);
        name.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        EditText category=settingField(form,"Categoria (es. Lavoro, Viaggio)",existing!=null?existing.optString("category"):"Personale",false);
        category.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        EditText note=settingField(form,"Note e descrizione",existing!=null?existing.optString("note"):"",false);
        note.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        note.setSingleLine(false);note.setMinLines(2);note.setMaxLines(4);
        output[0]=name;output[1]=category;output[2]=note;
        return form;
    }
    private String cleanText(EditText e,int limit){
        String s=e.getText().toString().trim();return s.length()>limit?s.substring(0,limit):s;
    }
    private void saveFavorite() {
        EditText[] fields=new EditText[3];
        ScrollView wrap=new ScrollView(this);wrap.addView(favoriteEditor(null,fields));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Nuovo preferito")
            .setView(wrap).setNegativeButton("Annulla",null).setPositiveButton("Salva",null).create();
        dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view->{
            String name=cleanText(fields[0],150);
            if(name.isEmpty()){fields[0].setError("Inserisci un nome");return;}
            try{
                JSONArray old=getItems("favorites"),out=new JSONArray();
                JSONObject rec=new JSONObject();
                rec.put("name",name).put("lat",latitude).put("lon",longitude)
                    .put("category",cleanText(fields[1],60)).put("note",cleanText(fields[2],500));
                out.put(rec);
                for(int i=0;i<old.length()&&out.length()<MAX_FAVORITES;i++){
                    JSONObject prev=old.optJSONObject(i);
                    if(prev==null)continue;
                    if(Math.abs(prev.optDouble("lat")-latitude)<1e-6 &&
                        Math.abs(prev.optDouble("lon")-longitude)<1e-6)continue;
                    out.put(prev);
                }
                putItems("favorites",out);
                message("Preferito salvato");dialog.dismiss();
            }catch(Exception ex){message("Impossibile salvare il preferito");}
        }));dialog.show();
    }
    private void editFavorite(JSONObject chosen,int index){
        if(chosen==null)return;
        EditText[] fields=new EditText[3];
        ScrollView wrap=new ScrollView(this);wrap.addView(favoriteEditor(chosen,fields));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Modifica preferito")
            .setView(wrap).setNegativeButton("Annulla",null).setPositiveButton("Salva",null).create();
        dlg.setOnShowListener(v->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view->{
            String name=cleanText(fields[0],150);
            if(name.isEmpty()){fields[0].setError("Inserisci un nome");return;}
            try{
                JSONArray data=getItems("favorites");
                if(index>=data.length()){message("Preferito non trovato");dlg.dismiss();return;}
                JSONObject rec=data.optJSONObject(index);
                if(rec==null){message("Preferito non valido");dlg.dismiss();return;}
                rec.put("name",name).put("category",cleanText(fields[1],60)).put("note",cleanText(fields[2],500));
                putItems("favorites",data);message("Preferito aggiornato");dlg.dismiss();
            }catch(Exception ex){message("Modifica non riuscita");}
        }));dlg.show();
    }
    private void showEntries(String key, String title) {
        JSONArray arr=getItems(key);
        if(arr.length()==0){message("Ancora nessun elemento in " + title.toLowerCase(Locale.ITALIAN));return;}
        String[] labels=new String[arr.length()];
        for(int i=0;i<arr.length();i++){
            JSONObject item=arr.optJSONObject(i);
            if(item==null){labels[i]="?";continue;}
            String category=item.optString("category","");
            String note=item.optString("note","");
            labels[i]=item.optString("name")+(category.isEmpty()?"":" · "+category)
                +(note.isEmpty()?"":"\n"+(note.length()>65?note.substring(0,65)+"…":note))
                +String.format(Locale.US,"\n%.5f, %.5f",item.optDouble("lat"),item.optDouble("lon"));
        }
        AlertDialog.Builder d=new AlertDialog.Builder(this).setTitle(title)
            .setItems(labels,(dlg,which)->{
                JSONObject item=arr.optJSONObject(which);
                if(item!=null)select(item.optDouble("lat"),item.optDouble("lon"));
            }).setNegativeButton("Chiudi",null)
            .setPositiveButton("Elimina",(dlg,w)->deleteEntry(key,title,labels));
        if("favorites".equals(key)){
            d.setNeutralButton("Modifica",(dlg,w)->new AlertDialog.Builder(this)
                .setTitle("Modifica quale preferito?")
                .setItems(labels,(inner,which)->editFavorite(arr.optJSONObject(which),which))
                .setNegativeButton("Annulla",null).show());
        }
        d.show();
    }
    private void deleteEntry(String key, String title, String[] labels) {
        new AlertDialog.Builder(this).setTitle("Elimina da " + title.toLowerCase(Locale.ITALIAN))
            .setItems(labels, (d, which) -> {
                JSONArray original = getItems(key), updated = new JSONArray();
                for (int i=0; i<original.length(); i++) if (i != which) updated.put(original.opt(i));
                putItems(key, updated); message("Elemento eliminato");
            }).setNegativeButton("Annulla", null).show();
    }

    /** Apre esattamente la coordinata scelta, non il punto GPS corrente. */
    private void openInMaps() {
        String coords = String.format(Locale.US, "%.7f,%.7f", latitude, longitude);
        Uri geo = Uri.parse("geo:0,0?q=" + Uri.encode(coords));
        Intent google = new Intent(Intent.ACTION_VIEW, geo);
        google.setPackage("com.google.android.apps.maps");
        try {
            startActivity(google);
        } catch (ActivityNotFoundException | SecurityException e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, geo));
            } catch (ActivityNotFoundException | SecurityException fallback) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(coords))));
                } catch (Exception last) { message("Non trovo un'app per aprire la mappa"); }
            }
        }
    }

    /** Salva un backup portabile con lo Storage Access Framework (nessun permesso storage). */
    private void exportFavorites() {
        JSONArray data = getItems("favorites");
        if (data.length() == 0) {
            message("Non ci sono preferiti da esportare");
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "LocationLab-preferiti.json");
        try { startActivityForResult(i, DOCUMENT_EXPORT); }
        catch (Exception e) { message("Impossibile aprire la finestra di esportazione"); }
    }

    private void importFavorites() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        try { startActivityForResult(i, DOCUMENT_IMPORT); }
        catch (Exception e) { message("Impossibile aprire la finestra di importazione"); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (requestCode == DOCUMENT_EXPORT) {
            try {
                JSONObject backup = new JSONObject();
                backup.put("app", "LocationLab");
                backup.put("version", 2);
                backup.put("exportedAt", System.currentTimeMillis());
                backup.put("favorites", getItems("favorites"));
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null) throw new java.io.IOException("Destinazione non disponibile");
                    out.write(backup.toString(2).getBytes(StandardCharsets.UTF_8));
                }
                message("Preferiti esportati correttamente");
            } catch (Exception e) { message("Esportazione non riuscita: " + e.getMessage()); }
        } else if (requestCode == DOCUMENT_IMPORT) {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new java.io.IOException("File non leggibile");
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                byte[] part = new byte[4096];
                int count;
                while ((count = in.read(part)) != -1) {
                    if (buffer.size() + count > 1024 * 1024)
                        throw new java.io.IOException("File troppo grande (massimo 1 MB)");
                    buffer.write(part, 0, count);
                }
                JSONObject backup = new JSONObject(new String(buffer.toByteArray(), StandardCharsets.UTF_8));
                if (!"LocationLab".equals(backup.optString("app")) ||
                    (backup.optInt("version", -1) != 1 && backup.optInt("version", -1) != 2))
                    throw new IllegalArgumentException("Formato backup LocationLab non valido");
                JSONArray incoming = backup.optJSONArray("favorites");
                if (incoming == null) throw new IllegalArgumentException("Elenco preferiti mancante");
                JSONArray old = getItems("favorites"), merged = new JSONArray();
                Set<String> used = new HashSet<>();
                for (int j = 0; j < old.length(); j++) {
                    JSONObject item = old.optJSONObject(j);
                    if (item == null) continue;
                    double lat = item.optDouble("lat", Double.NaN);
                    double lon = item.optDouble("lon", Double.NaN);
                    if (validCoordinates(lat, lon) && merged.length() < MAX_FAVORITES) {
                        used.add(String.format(Locale.US, "%.6f,%.6f", lat, lon));
                        merged.put(item);
                    }
                }
                int added = 0;
                for (int j = 0; j < incoming.length() && merged.length() < MAX_FAVORITES; j++) {
                    JSONObject item = incoming.optJSONObject(j);
                    if (item == null) continue;
                    double lat = item.optDouble("lat", Double.NaN);
                    double lon = item.optDouble("lon", Double.NaN);
                    String name = item.optString("name", "").trim();
                    if (name.isEmpty() || !validCoordinates(lat, lon)) continue;
                    String key = String.format(Locale.US, "%.6f,%.6f", lat, lon);
                    if (!used.add(key)) continue;
                    JSONObject clean = new JSONObject();
                    clean.put("name", name.length() > 150 ? name.substring(0, 150) : name);
                    clean.put("lat", lat);
                    clean.put("lon", lon);
                    String category=item.optString("category","");
                    String note=item.optString("note","");
                    clean.put("category",category.length()>60?category.substring(0,60):category);
                    clean.put("note",note.length()>500?note.substring(0,500):note);
                    merged.put(clean);
                    added++;
                }
                if (incoming.length() > 0 && added == 0) {
                    message("Nessun nuovo preferito da importare");
                } else {
                    putItems("favorites", merged);
                    message("Importati " + added + " preferiti; esistenti conservati");
                }
            } catch (Exception e) { message("Importazione non riuscita: " + e.getMessage()); }
        }
    }

    private boolean validCoordinates(double lat, double lon) {
        return Double.isFinite(lat) && Double.isFinite(lon)
            && lat >= -85 && lat <= 85 && lon >= -180 && lon <= 180;
    }

    /** Non confonde la posizione fittizia con quella vera. */
    private void recenterOnDevice() {
        if (getSharedPreferences("state", MODE_PRIVATE).getBoolean("running", false)) {
            new AlertDialog.Builder(this)
                .setTitle("Posizione reale")
                .setMessage("La simulazione GPS è attiva. Per ritrovare la posizione reale ferma prima la simulazione, poi tocca nuovamente ◎.")
                .setPositiveButton("OK", null).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_RECENTER);
            return;
        }
        try {
            locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (locationManager == null) { message("Localizzazione non disponibile"); return; }
            boolean gps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            boolean network = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            if (!gps && !network) {
                new AlertDialog.Builder(this).setTitle("Attiva la posizione")
                    .setMessage("La posizione del telefono è disattivata.")
                    .setNegativeButton("Annulla", null)
                    .setPositiveButton("Impostazioni", (d,w) -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .show();
                return;
            }
            stopLocationRequest();
            message("Ricerca della posizione reale…");
            locationListener = new LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    if (location == null || location.isFromMockProvider()) return;
                    double lat = location.getLatitude(), lon = location.getLongitude();
                    if (!validCoordinates(lat, lon)) return;
                    stopLocationRequest();
                    select(lat, lon);
                    message("Mappa centrata sulla posizione attuale");
                }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
                @Override public void onProviderEnabled(String provider) { }
                @Override public void onProviderDisabled(String provider) { }
            };
            if (gps) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0L, 0f, locationListener, Looper.getMainLooper());
            if (network) locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0f, locationListener, Looper.getMainLooper());
            locationTimeout = () -> {
                stopLocationRequest();
                message("Nessuna posizione GPS reale recente. Riprova all'aperto.");
            };
            mainHandler.postDelayed(locationTimeout, 20000L);
        } catch (SecurityException e) { stopLocationRequest(); message("Permesso posizione non concesso"); }
          catch (Exception e) { stopLocationRequest(); message("Impossibile rilevare la posizione reale"); }
    }

    private void stopLocationRequest() {
        if (locationTimeout != null) { mainHandler.removeCallbacks(locationTimeout); locationTimeout = null; }
        if (locationManager != null && locationListener != null) {
            try { locationManager.removeUpdates(locationListener); } catch (Exception ignored) { }
        }
        locationListener = null;
    }

    private boolean mockSelected() {
        AppOpsManager manager = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
        return manager != null && manager.checkOpNoThrow(AppOpsManager.OPSTR_MOCK_LOCATION,
            android.os.Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
    }
    private void startSimulation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSIONS);
            return;
        }
        if (!mockSelected()) {
            new AlertDialog.Builder(this).setTitle("Seleziona LocationLab come app di posizione fittizia")
                .setMessage("Nelle Opzioni sviluppatore di Android seleziona “App per posizione simulata” e scegli LocationLab. È necessario per il funzionamento senza root.")
                .setNegativeButton("Annulla", null)
                .setPositiveButton("Apri impostazioni", (d,w) -> openDevSettings()).show();
            return;
        }
        remember("history", String.format(Locale.US, "%.5f, %.5f", latitude, longitude));
        try {
            getSharedPreferences("state", MODE_PRIVATE).edit().remove("error").apply();
            Intent intent = new Intent(this, MockLocationService.class);
            intent.setAction(MockLocationService.ACTION_START);
            android.content.SharedPreferences p=pref();
            boolean route=p.getBoolean("route_enabled",false);
            double fromLat=route?storedCoord(p,"route_start_lat",latitude):latitude;
            double fromLon=route?storedCoord(p,"route_start_lon",longitude):longitude;
            double endLat=route?storedCoord(p,"route_end_lat",latitude):latitude;
            double endLon=route?storedCoord(p,"route_end_lon",longitude):longitude;
            intent.putExtra(MockLocationService.EXTRA_LAT, fromLat);
            intent.putExtra(MockLocationService.EXTRA_LON, fromLon);
            intent.putExtra(MockLocationService.EXTRA_ROUTE, route);
            intent.putExtra(MockLocationService.EXTRA_END_LAT, endLat);
            intent.putExtra(MockLocationService.EXTRA_END_LON, endLon);
            intent.putExtra(MockLocationService.EXTRA_ALTITUDE,(double)p.getFloat("gps_altitude_m",0f));
            intent.putExtra(MockLocationService.EXTRA_ACCURACY,(double)p.getFloat("gps_accuracy_m",3f));
            intent.putExtra(MockLocationService.EXTRA_SPEED_MPS,(double)p.getFloat(
                route?"route_speed_mps":"gps_speed_mps",0f));
            intent.putExtra(MockLocationService.EXTRA_JITTER,(double)p.getFloat("gps_jitter_m",0f));
            getSharedPreferences("state",MODE_PRIVATE).edit().remove("routeCompleted").apply();
            startForegroundService(intent);
            refreshSimulationState();
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 52);
            }
        } catch (Exception ex) { message("Avvio non riuscito: " + ex.getMessage()); }
    }
    private void stopSimulation() {
        Intent intent = new Intent(this, MockLocationService.class);
        intent.setAction(MockLocationService.ACTION_STOP);
        try { startService(intent); refreshSimulationState(); }
        catch (Exception ex) { message("Arresto non riuscito"); }
    }
    private void openDevSettings() {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
        catch (Exception ex) { message("Apri Impostazioni → Opzioni sviluppatore"); }
    }
    @Override public void onRequestPermissionsResult(int req, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(req, permissions, grants);
        if (req == PERMISSIONS && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) startSimulation();
        else if (req == PERMISSIONS) message("Serve il permesso di localizzazione per avviare il servizio GPS");
        else if (req == PERMISSION_RECENTER && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) recenterOnDevice();
        else if (req == PERMISSION_RECENTER) message("Consenti la posizione precisa per centrare la mappa");
    }
    @Override protected void onResume() {
        super.onResume();
        mainHandler.removeCallbacks(stateMonitor);
        mainHandler.post(stateMonitor);
        if (status != null) {
            android.content.SharedPreferences simulation = getSharedPreferences("state", MODE_PRIVATE);
            String error = simulation.getString("error", null);
            refreshSimulationState();
            if (error != null && !error.isEmpty()) {
                simulation.edit().remove("error").apply();
                message(error);
            }
        }
    }
    private void message(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }
    @Override protected void onPause() {
        mainHandler.removeCallbacks(stateMonitor);
        super.onPause();
    }
    @Override protected void onDestroy() {
        mainHandler.removeCallbacks(stateMonitor);
        stopLocationRequest(); worker.shutdownNow(); super.onDestroy();
    }
}
