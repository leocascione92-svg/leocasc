package it.locationlab.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;
import java.util.concurrent.*;

/** App Android ad-free sviluppata indipendentemente. */
public final class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(25, 59, 100);
    private static final int CYAN = Color.rgb(40, 144, 191);
    private static final int INK = Color.rgb(36, 52, 70);
    private static final int PERMISSIONS = 51;
    private TileMapView map;
    private TextView position, status;
    private double latitude = 41.893, longitude = 12.483;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10, 14, 22));
        getWindow().setNavigationBarColor(Color.rgb(10, 14, 22));
        getWindow().getDecorView().setSystemUiVisibility(0);
        latitude = Double.longBitsToDouble(getPreferences(MODE_PRIVATE).getLong("latitude", Double.doubleToRawLongBits(latitude)));
        longitude = Double.longBitsToDouble(getPreferences(MODE_PRIVATE).getLong("longitude", Double.doubleToRawLongBits(longitude)));
        if (!Double.isFinite(latitude) || latitude < -85 || latitude > 85) latitude = 41.893;
        if (!Double.isFinite(longitude) || longitude < -180 || longitude > 180) longitude = 12.483;
        buildUi();
        updatePosition();
    }

    private static final int BACKGROUND = Color.rgb(10, 14, 22);
    private static final int SURFACE = Color.rgb(18, 26, 39);
    private static final int SURFACE_HIGH = Color.rgb(30, 42, 58);
    private static final int TEXT_PRIMARY = Color.rgb(239, 244, 250);
    private static final int TEXT_SECONDARY = Color.rgb(145, 163, 183);
    private static final int ACCENT = Color.rgb(81, 218, 188);
    private TextView primaryAction;

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BACKGROUND);
        setContentView(root);
        // Android 15/16 applica edge-to-edge obbligatorio: lo spazio dei controlli
        // viene aggiustato usando gli inset reali delle barre di sistema.
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                view.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
                return insets;
            });
            root.requestApplyInsets();
        }

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(19), 0, dp(12), 0);
        top.setBackgroundColor(BACKGROUND);
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(60)));
        TextView logo = label("◉", 27, ACCENT, true);
        top.addView(logo, new LinearLayout.LayoutParams(dp(38), -1));
        TextView title = label("LocationLab", 21, TEXT_PRIMARY, true);
        top.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        status = label("●  Pronto", 12, ACCENT, true);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(11), 0, dp(11), 0);
        status.setBackground(round(SURFACE_HIGH, 100));
        top.addView(status, new LinearLayout.LayoutParams(-2, dp(32)));
        TextView menu = label("⋮", 27, TEXT_PRIMARY, false);
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription("Altre opzioni");
        top.addView(menu, new LinearLayout.LayoutParams(dp(42), dp(48)));
        menu.setOnClickListener(v -> showMenu(menu));

        FrameLayout mapArea = new FrameLayout(this);
        root.addView(mapArea, new LinearLayout.LayoutParams(-1, 0, 1));
        map = new TileMapView(this);
        map.setDarkMode(getPreferences(MODE_PRIVATE).getBoolean("darkMap", true));
        map.setPosition(latitude, longitude, true);
        map.setOnSelectedListener((lat, lon) -> { latitude = lat; longitude = lon; updatePosition(); });
        mapArea.addView(map, new FrameLayout.LayoutParams(-1, -1));

        TextView search = label("⌕   Cerca un indirizzo o un luogo", 14, TEXT_SECONDARY, false);
        search.setPadding(dp(17), 0, dp(14), 0);
        search.setBackground(round(SURFACE, 18));
        search.setElevation(dp(4));
        search.setContentDescription("Cerca un luogo sulla mappa");
        FrameLayout.LayoutParams searchLp = new FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP);
        searchLp.setMargins(dp(16), dp(16), dp(75), 0);
        mapArea.addView(search, searchLp);
        search.setOnClickListener(v -> search());

        LinearLayout zooms = new LinearLayout(this);
        zooms.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams zoomLp = new FrameLayout.LayoutParams(dp(47), -2, Gravity.TOP | Gravity.RIGHT);
        zoomLp.setMargins(0, dp(18), dp(16), 0);
        mapArea.addView(zooms, zoomLp);
        TextView zoomIn = squareAction("+", () -> map.zoomBy(1));
        TextView zoomOut = squareAction("−", () -> map.zoomBy(-1));
        zooms.addView(zoomIn, new LinearLayout.LayoutParams(-1, dp(46)));
        LinearLayout.LayoutParams minusParams = new LinearLayout.LayoutParams(-1, dp(46));
        minusParams.topMargin = dp(7);
        zooms.addView(zoomOut, minusParams);

        TextView attribution = label("© OpenStreetMap contributors", 10, TEXT_PRIMARY, false);
        attribution.setPadding(dp(9), dp(5), dp(9), dp(5));
        attribution.setBackground(round(Color.rgb(33, 44, 58), 8));
        FrameLayout.LayoutParams attr = new FrameLayout.LayoutParams(-2, -2, Gravity.LEFT | Gravity.BOTTOM);
        attr.setMargins(dp(12), 0, 0, dp(10));
        mapArea.addView(attribution, attr);

        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(20), dp(10), dp(20), dp(16));
        GradientDrawable surface = new GradientDrawable();
        surface.setColor(SURFACE);
        surface.setCornerRadii(new float[]{dp(23),dp(23),dp(23),dp(23),0,0,0,0});
        sheet.setBackground(surface);
        root.addView(sheet, new LinearLayout.LayoutParams(-1, -2));

        TextView handle = label("", 2, TEXT_SECONDARY, false);
        handle.setBackground(round(Color.rgb(78, 95, 112), 100));
        LinearLayout.LayoutParams handleLp = new LinearLayout.LayoutParams(dp(38), dp(4));
        handleLp.gravity = Gravity.CENTER_HORIZONTAL;
        handleLp.bottomMargin = dp(15);
        sheet.addView(handle, handleLp);

        LinearLayout pointRow = new LinearLayout(this);
        pointRow.setGravity(Gravity.CENTER_VERTICAL);
        sheet.addView(pointRow, new LinearLayout.LayoutParams(-1, dp(35)));
        TextView pointIcon = label("⌖", 23, ACCENT, true);
        pointRow.addView(pointIcon, new LinearLayout.LayoutParams(dp(35), -1));
        TextView pointLabel = label("POSIZIONE SELEZIONATA", 11, TEXT_SECONDARY, true);
        pointRow.addView(pointLabel, new LinearLayout.LayoutParams(0, -1, 1));
        TextView save = label("☆  Salva", 13, ACCENT, true);
        save.setGravity(Gravity.CENTER);
        save.setPadding(dp(12), 0, dp(12), 0);
        save.setBackground(round(SURFACE_HIGH, 13));
        pointRow.addView(save, new LinearLayout.LayoutParams(-2, dp(35)));
        save.setOnClickListener(v -> saveFavorite());

        position = label("", 20, TEXT_PRIMARY, true);
        position.setTypeface(Typeface.create("monospace", Typeface.BOLD));
        position.setPadding(dp(3), dp(5), 0, dp(12));
        position.setContentDescription("Coordinate selezionate. Tocca per modificarle");
        sheet.addView(position, new LinearLayout.LayoutParams(-1, -2));
        position.setOnClickListener(v -> enterCoordinates());

        LinearLayout tools = new LinearLayout(this);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        sheet.addView(tools, new LinearLayout.LayoutParams(-1, dp(43)));
        addTextAction(tools, "✎  Coordinate", v -> enterCoordinates());
        addTextAction(tools, "☆  Preferiti", v -> showEntries("favorites", "Preferiti"));
        addTextAction(tools, "↶  Cronologia", v -> showEntries("history", "Cronologia"));

        primaryAction = label("▶  Avvia simulazione", 16, BACKGROUND, true);
        primaryAction.setGravity(Gravity.CENTER);
        primaryAction.setBackground(round(ACCENT, 16));
        primaryAction.setContentDescription("Avvia o arresta il GPS simulato");
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, dp(54));
        actionLp.topMargin = dp(8);
        sheet.addView(primaryAction, actionLp);
        primaryAction.setOnClickListener(v -> {
            boolean running = getSharedPreferences("state", MODE_PRIVATE).getBoolean("running", false);
            if (running) stopSimulation(); else startSimulation();
            refreshSimulationState();
        });
        TextView hint = label("Tocca la mappa per scegliere un punto · Pizzica per ingrandire", 11, TEXT_SECONDARY, false);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, dp(25));
        hintLp.topMargin = dp(5);
        sheet.addView(hint, hintLp);
    }

    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }
    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(false);
        return t;
    }
    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radiusDp));
        return bg;
    }
    private TextView squareAction(String value, Runnable action) {
        TextView v = label(value, 26, TEXT_PRIMARY, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(round(SURFACE, 14));
        v.setElevation(dp(3));
        v.setOnClickListener(w -> action.run());
        v.setContentDescription(value.equals("+") ? "Ingrandisci mappa" : "Riduci mappa");
        return v;
    }
    private void addTextAction(LinearLayout row, String text, View.OnClickListener action) {
        TextView view = label(text, 12, TEXT_SECONDARY, true);
        view.setGravity(Gravity.CENTER);
        row.addView(view, new LinearLayout.LayoutParams(0, -1, 1f));
        view.setOnClickListener(action);
    }
    private void showMenu(View anchor) {
        PopupMenu pop = new PopupMenu(this, anchor);
        pop.getMenu().add("Cerca un luogo").setOnMenuItemClickListener(i -> {search(); return true;});
        pop.getMenu().add("Inserisci coordinate").setOnMenuItemClickListener(i -> {enterCoordinates(); return true;});
        pop.getMenu().add("Preferiti").setOnMenuItemClickListener(i -> {showEntries("favorites", "Preferiti"); return true;});
        pop.getMenu().add("Cronologia").setOnMenuItemClickListener(i -> {showEntries("history", "Cronologia"); return true;});
        pop.getMenu().add(map.isDarkMode() ? "Mappa chiara" : "Mappa scura").setOnMenuItemClickListener(i -> {
            boolean dark = !map.isDarkMode();
            map.setDarkMode(dark);
            getPreferences(MODE_PRIVATE).edit().putBoolean("darkMap", dark).apply();
            return true;
        });
        pop.getMenu().add("Opzioni sviluppatore · Posizione fittizia").setOnMenuItemClickListener(i -> {openDevSettings();return true;});
        pop.show();
    }
    private void refreshSimulationState() {
        if (status == null || primaryAction == null) return;
        android.content.SharedPreferences s = getSharedPreferences("state", MODE_PRIVATE);
        boolean running = s.getBoolean("running", false);
        status.setText(running ? "●  Attivo" : "●  Pronto");
        status.setTextColor(running ? ACCENT : TEXT_SECONDARY);
        primaryAction.setText(running ? "■  Ferma simulazione" : "▶  Avvia simulazione");
        primaryAction.setTextColor(running ? TEXT_PRIMARY : BACKGROUND);
        primaryAction.setBackground(round(running ? Color.rgb(128, 52, 62) : ACCENT, 16));
    }

    private void updatePosition() {
        position.setText(String.format(Locale.US, "%.6f°, %.6f°", latitude, longitude));
        getPreferences(MODE_PRIVATE).edit().putLong("latitude", Double.doubleToRawLongBits(latitude))
            .putLong("longitude", Double.doubleToRawLongBits(longitude)).apply();
    }
    private void select(double lat, double lon) {
        if (!Double.isFinite(lat) || !Double.isFinite(lon) || lat < -85 || lat > 85 || lon < -180 || lon > 180) {
            message("Coordinate fuori intervallo valido"); return;
        }
        latitude = lat; longitude = lon;
        map.setPosition(lat, lon, true);
        updatePosition();
    }
    private void enterCoordinates() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("41.893, 12.483");
        input.setText(String.format(Locale.US, "%.6f, %.6f", latitude, longitude));
        new AlertDialog.Builder(this).setTitle("Inserisci latitudine, longitudine")
            .setView(input).setNegativeButton("Annulla", null)
            .setPositiveButton("Vai", (d, w) -> {
                try {
                    String[] parts = input.getText().toString().trim().split("[,;\\s]+", 2);
                    if (parts.length != 2) throw new NumberFormatException();
                    select(Double.parseDouble(parts[0]), Double.parseDouble(parts[1]));
                } catch (Exception e) { message("Formato: latitudine, longitudine (con punto decimale)"); }
            }).show();
    }
    private void search() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Es. Piazza Duomo, Milano");
        new AlertDialog.Builder(this).setTitle("Cerca un indirizzo")
            .setMessage("Ricerca tramite il servizio di geocodifica del dispositivo")
            .setView(input).setNegativeButton("Annulla", null)
            .setPositiveButton("Cerca", (d, w) -> {
                String query = input.getText().toString().trim();
                if (query.length() < 3) return;
                status.setText("Ricerca…");
                worker.execute(() -> {
                    try {
                        Geocoder geocoder = new Geocoder(this, Locale.ITALIAN);
                        List<Address> results = geocoder.getFromLocationName(query, 1);
                        runOnUiThread(() -> {
                            refreshSimulationState();
                            if (results == null || results.isEmpty()) message("Nessun luogo trovato");
                            else select(results.get(0).getLatitude(), results.get(0).getLongitude());
                        });
                    } catch (Exception e) {
                        runOnUiThread(() -> { refreshSimulationState(); message("Ricerca non disponibile su questo dispositivo"); });
                    }
                });
            }).show();
    }

    private JSONArray getItems(String key) {
        try { return new JSONArray(getPreferences(MODE_PRIVATE).getString(key, "[]")); }
        catch (Exception ex) { return new JSONArray(); }
    }
    private void putItems(String key, JSONArray list) {
        getPreferences(MODE_PRIVATE).edit().putString(key, list.toString()).apply();
    }
    private void remember(String key, String name) {
        try {
            JSONArray input = getItems(key);
            JSONArray output = new JSONArray();
            JSONObject record = new JSONObject();
            record.put("name", name).put("lat", latitude).put("lon", longitude);
            output.put(record);
            for (int i=0; i<input.length() && output.length() < 40; i++) {
                JSONObject previous = input.optJSONObject(i);
                if (previous == null) continue;
                if (Math.abs(previous.optDouble("lat")-latitude)<0.000001 &&
                    Math.abs(previous.optDouble("lon")-longitude)<0.000001) continue;
                output.put(previous);
            }
            putItems(key, output);
        } catch (Exception ex) { message("Impossibile salvare"); }
    }
    private void saveFavorite() {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setText(String.format(Locale.US, "Luogo %.4f, %.4f", latitude, longitude));
        new AlertDialog.Builder(this).setTitle("Salva nei preferiti")
            .setView(field).setNegativeButton("Annulla", null)
            .setPositiveButton("Salva", (d,w) -> { remember("favorites", field.getText().toString()); message("Preferito salvato"); }).show();
    }
    private void showEntries(String key, String title) {
        JSONArray arr = getItems(key);
        if (arr.length() == 0) { message("Ancora nessun elemento in " + title.toLowerCase(Locale.ITALIAN)); return; }
        String[] labels = new String[arr.length()];
        for (int i=0; i<arr.length(); i++) {
            JSONObject item = arr.optJSONObject(i);
            labels[i] = item == null ? "?" : item.optString("name") + "\n" +
                String.format(Locale.US, "%.5f, %.5f", item.optDouble("lat"), item.optDouble("lon"));
        }
        new AlertDialog.Builder(this).setTitle(title).setItems(labels, (d,which) -> {
            JSONObject item = arr.optJSONObject(which);
            if (item != null) select(item.optDouble("lat"), item.optDouble("lon"));
        }).setNeutralButton("Gestisci", (d,w) -> deleteEntry(key, title, labels))
            .setNegativeButton("Chiudi", null).show();
    }
    private void deleteEntry(String key, String title, String[] labels) {
        new AlertDialog.Builder(this).setTitle("Elimina da " + title.toLowerCase(Locale.ITALIAN))
            .setItems(labels, (d, which) -> {
                JSONArray original = getItems(key), updated = new JSONArray();
                for (int i=0; i<original.length(); i++) if (i != which) updated.put(original.opt(i));
                putItems(key, updated); message("Elemento eliminato");
            }).setNegativeButton("Annulla", null).show();
    }

    private boolean mockSelected() {
        AppOpsManager manager = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
        return manager != null && manager.checkOpNoThrow(AppOpsManager.OPSTR_MOCK_LOCATION,
            android.os.Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
    }
    private void startSimulation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSIONS);
            return;
        }
        if (!mockSelected()) {
            new AlertDialog.Builder(this).setTitle("Seleziona LocationLab come app di posizione fittizia")
                .setMessage("Nelle Opzioni sviluppatore di Android seleziona “App per posizione simulata” e scegli LocationLab. È necessario per il funzionamento senza root.")
                .setNegativeButton("Annulla", null)
                .setPositiveButton("Apri impostazioni", (d,w) -> openDevSettings()).show();
            return;
        }
        remember("history", String.format(Locale.US, "%.5f, %.5f", latitude, longitude));
        try {
            getSharedPreferences("state", MODE_PRIVATE).edit().remove("error").apply();
            Intent intent = new Intent(this, MockLocationService.class);
            intent.setAction(MockLocationService.ACTION_START);
            intent.putExtra(MockLocationService.EXTRA_LAT, latitude);
            intent.putExtra(MockLocationService.EXTRA_LON, longitude);
            startForegroundService(intent);
            refreshSimulationState();
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 52);
            }
        } catch (Exception ex) { message("Avvio non riuscito: " + ex.getMessage()); }
    }
    private void stopSimulation() {
        Intent intent = new Intent(this, MockLocationService.class);
        intent.setAction(MockLocationService.ACTION_STOP);
        try { startService(intent); refreshSimulationState(); }
        catch (Exception ex) { message("Arresto non riuscito"); }
    }
    private void openDevSettings() {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
        catch (Exception ex) { message("Apri Impostazioni → Opzioni sviluppatore"); }
    }
    @Override public void onRequestPermissionsResult(int req, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(req, permissions, grants);
        if (req == PERMISSIONS && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) startSimulation();
        else if (req == PERMISSIONS) message("Serve il permesso di localizzazione per avviare il servizio GPS");
    }
    @Override protected void onResume() {
        super.onResume();
        if (status != null) {
            android.content.SharedPreferences simulation = getSharedPreferences("state", MODE_PRIVATE);
            String error = simulation.getString("error", null);
            refreshSimulationState();
            if (error != null && !error.isEmpty()) {
                simulation.edit().remove("error").apply();
                message(error);
            }
        }
    }
    private void message(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }
    @Override protected void onDestroy() { worker.shutdownNow(); super.onDestroy(); }
}
