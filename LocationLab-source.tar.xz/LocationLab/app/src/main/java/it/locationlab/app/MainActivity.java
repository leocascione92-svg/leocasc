package it.locationlab.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;
import java.util.concurrent.*;

/** App Android ad-free sviluppata indipendentemente. */
public final class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(25, 59, 100);
    private static final int CYAN = Color.rgb(40, 144, 191);
    private static final int INK = Color.rgb(36, 52, 70);
    private static final int PERMISSIONS = 51;
    private TileMapView map;
    private TextView position, status;
    private double latitude = 41.893, longitude = 12.483;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(Color.rgb(243, 246, 249));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        latitude = Double.longBitsToDouble(getPreferences(MODE_PRIVATE).getLong("latitude", Double.doubleToRawLongBits(latitude)));
        longitude = Double.longBitsToDouble(getPreferences(MODE_PRIVATE).getLong("longitude", Double.doubleToRawLongBits(longitude)));
        if (!Double.isFinite(latitude) || latitude < -85 || latitude > 85) latitude = 41.893;
        if (!Double.isFinite(longitude) || longitude < -180 || longitude > 180) longitude = 12.483;
        buildUi();
        updatePosition();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(247, 249, 251));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setPadding(dp(17), dp(12), dp(17), dp(12));
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(NAVY);
        TextView title = text("LocationLab", 22, Color.WHITE, true);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(36), 1));
        status = text("Pronto", 12, Color.WHITE, false);
        status.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        header.addView(status);
        root.addView(header);

        FrameLayout mapBox = new FrameLayout(this);
        root.addView(mapBox, new LinearLayout.LayoutParams(-1, 0, 1));
        map = new TileMapView(this);
        map.setPosition(latitude, longitude, true);
        map.setOnSelectedListener((lat, lon) -> { latitude = lat; longitude = lon; updatePosition(); });
        mapBox.addView(map, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout zooms = new LinearLayout(this);
        zooms.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams zoomParams = new FrameLayout.LayoutParams(dp(53), -2, Gravity.RIGHT | Gravity.TOP);
        zoomParams.setMargins(0, dp(18), dp(13), 0);
        mapBox.addView(zooms, zoomParams);
        Button plus = button("+", CYAN); zooms.addView(plus, new LinearLayout.LayoutParams(-1, dp(48)));
        plus.setOnClickListener(v -> map.zoomBy(1));
        Button minus = button("−", CYAN); zooms.addView(minus, new LinearLayout.LayoutParams(-1, dp(48)));
        minus.setOnClickListener(v -> map.zoomBy(-1));

        TextView attribution = text("© OpenStreetMap contributors", 11, NAVY, false);
        attribution.setBackgroundColor(Color.argb(230, 255, 255, 255));
        attribution.setPadding(dp(7), dp(3), dp(7), dp(3));
        FrameLayout.LayoutParams attr = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.RIGHT);
        attr.setMargins(dp(4), 0, dp(5), dp(5));
        mapBox.addView(attribution, attr);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setPadding(dp(15), dp(9), dp(15), dp(13));
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setBackgroundColor(Color.WHITE);
        root.addView(bottom);

        TextView subtitle = text("POSIZIONE SELEZIONATA", 11, CYAN, true);
        bottom.addView(subtitle);
        position = text("", 19, INK, true);
        position.setPadding(0, dp(2), 0, dp(10));
        bottom.addView(position);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        bottom.addView(row1);
        addButton(row1, "Cerca luogo", CYAN, v -> search(), 1f);
        addButton(row1, "Coordinate", CYAN, v -> enterCoordinates(), 1f);
        addButton(row1, "☆ Salva", CYAN, v -> saveFavorite(), 0.9f);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams row2params = new LinearLayout.LayoutParams(-1, -2);
        row2params.topMargin = dp(4);
        bottom.addView(row2, row2params);
        addButton(row2, "Preferiti", NAVY, v -> showEntries("favorites", "Preferiti"), 1f);
        addButton(row2, "Cronologia", NAVY, v -> showEntries("history", "Cronologia"), 1f);
        addButton(row2, "Opzioni GPS", NAVY, v -> openDevSettings(), 1.15f);

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams row3params = new LinearLayout.LayoutParams(-1, -2);
        row3params.topMargin = dp(6);
        bottom.addView(row3, row3params);
        addButton(row3, "▶ Avvia simulazione", Color.rgb(34, 128, 91), v -> startSimulation(), 2.1f);
        addButton(row3, "■ Ferma", Color.rgb(181, 69, 73), v -> stopSimulation(), 1f);
    }

    private int dp(int d) { return Math.round(getResources().getDisplayMetrics().density * d); }
    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }
    private Button button(String value, int bg) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextSize(12);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setPadding(dp(3), 0, dp(3), 0);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(bg); shape.setCornerRadius(dp(9));
        button.setBackground(shape);
        return button;
    }
    private void addButton(LinearLayout row, String value, int bg, View.OnClickListener action, float weight) {
        Button button = button(value, bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(45), weight);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        row.addView(button, lp);
        button.setOnClickListener(action);
    }

    private void updatePosition() {
        position.setText(String.format(Locale.US, "%.6f°, %.6f°", latitude, longitude));
        getPreferences(MODE_PRIVATE).edit().putLong("latitude", Double.doubleToRawLongBits(latitude))
            .putLong("longitude", Double.doubleToRawLongBits(longitude)).apply();
    }
    private void select(double lat, double lon) {
        if (!Double.isFinite(lat) || !Double.isFinite(lon) || lat < -85 || lat > 85 || lon < -180 || lon > 180) {
            message("Coordinate fuori intervallo valido"); return;
        }
        latitude = lat; longitude = lon;
        map.setPosition(lat, lon, true);
        updatePosition();
    }
    private void enterCoordinates() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("41.893, 12.483");
        input.setText(String.format(Locale.US, "%.6f, %.6f", latitude, longitude));
        new AlertDialog.Builder(this).setTitle("Inserisci latitudine, longitudine")
            .setView(input).setNegativeButton("Annulla", null)
            .setPositiveButton("Vai", (d, w) -> {
                try {
                    String[] parts = input.getText().toString().trim().split("[,;\\s]+", 2);
                    if (parts.length != 2) throw new NumberFormatException();
                    select(Double.parseDouble(parts[0]), Double.parseDouble(parts[1]));
                } catch (Exception e) { message("Formato: latitudine, longitudine (con punto decimale)"); }
            }).show();
    }
    private void search() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Es. Piazza Duomo, Milano");
        new AlertDialog.Builder(this).setTitle("Cerca un indirizzo")
            .setMessage("Ricerca tramite il servizio di geocodifica del dispositivo")
            .setView(input).setNegativeButton("Annulla", null)
            .setPositiveButton("Cerca", (d, w) -> {
                String query = input.getText().toString().trim();
                if (query.length() < 3) return;
                status.setText("Ricerca...");
                worker.execute(() -> {
                    try {
                        Geocoder geocoder = new Geocoder(this, Locale.ITALIAN);
                        List<Address> results = geocoder.getFromLocationName(query, 1);
                        runOnUiThread(() -> {
                            status.setText("Pronto");
                            if (results == null || results.isEmpty()) message("Nessun luogo trovato");
                            else select(results.get(0).getLatitude(), results.get(0).getLongitude());
                        });
                    } catch (Exception e) {
                        runOnUiThread(() -> { status.setText("Pronto"); message("Ricerca non disponibile su questo dispositivo"); });
                    }
                });
            }).show();
    }

    private JSONArray getItems(String key) {
        try { return new JSONArray(getPreferences(MODE_PRIVATE).getString(key, "[]")); }
        catch (Exception ex) { return new JSONArray(); }
    }
    private void putItems(String key, JSONArray list) {
        getPreferences(MODE_PRIVATE).edit().putString(key, list.toString()).apply();
    }
    private void remember(String key, String name) {
        try {
            JSONArray input = getItems(key);
            JSONArray output = new JSONArray();
            JSONObject record = new JSONObject();
            record.put("name", name).put("lat", latitude).put("lon", longitude);
            output.put(record);
            for (int i=0; i<input.length() && output.length() < 40; i++) {
                JSONObject previous = input.optJSONObject(i);
                if (previous == null) continue;
                if (Math.abs(previous.optDouble("lat")-latitude)<0.000001 &&
                    Math.abs(previous.optDouble("lon")-longitude)<0.000001) continue;
                output.put(previous);
            }
            putItems(key, output);
        } catch (Exception ex) { message("Impossibile salvare"); }
    }
    private void saveFavorite() {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setText(String.format(Locale.US, "Luogo %.4f, %.4f", latitude, longitude));
        new AlertDialog.Builder(this).setTitle("Salva nei preferiti")
            .setView(field).setNegativeButton("Annulla", null)
            .setPositiveButton("Salva", (d,w) -> { remember("favorites", field.getText().toString()); message("Preferito salvato"); }).show();
    }
    private void showEntries(String key, String title) {
        JSONArray arr = getItems(key);
        if (arr.length() == 0) { message("Ancora nessun elemento in " + title.toLowerCase(Locale.ITALIAN)); return; }
        String[] labels = new String[arr.length()];
        for (int i=0; i<arr.length(); i++) {
            JSONObject item = arr.optJSONObject(i);
            labels[i] = item == null ? "?" : item.optString("name") + "\n" +
                String.format(Locale.US, "%.5f, %.5f", item.optDouble("lat"), item.optDouble("lon"));
        }
        new AlertDialog.Builder(this).setTitle(title).setItems(labels, (d,which) -> {
            JSONObject item = arr.optJSONObject(which);
            if (item != null) select(item.optDouble("lat"), item.optDouble("lon"));
        }).setNeutralButton("Gestisci", (d,w) -> deleteEntry(key, title, labels))
            .setNegativeButton("Chiudi", null).show();
    }
    private void deleteEntry(String key, String title, String[] labels) {
        new AlertDialog.Builder(this).setTitle("Elimina da " + title.toLowerCase(Locale.ITALIAN))
            .setItems(labels, (d, which) -> {
                JSONArray original = getItems(key), updated = new JSONArray();
                for (int i=0; i<original.length(); i++) if (i != which) updated.put(original.opt(i));
                putItems(key, updated); message("Elemento eliminato");
            }).setNegativeButton("Annulla", null).show();
    }

    private boolean mockSelected() {
        AppOpsManager manager = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
        return manager != null && manager.checkOpNoThrow(AppOpsManager.OPSTR_MOCK_LOCATION,
            android.os.Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
    }
    private void startSimulation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSIONS);
            return;
        }
        if (!mockSelected()) {
            new AlertDialog.Builder(this).setTitle("Seleziona LocationLab come app di posizione fittizia")
                .setMessage("Nelle Opzioni sviluppatore di Android seleziona “App per posizione simulata” e scegli LocationLab. È necessario per il funzionamento senza root.")
                .setNegativeButton("Annulla", null)
                .setPositiveButton("Apri impostazioni", (d,w) -> openDevSettings()).show();
            return;
        }
        remember("history", String.format(Locale.US, "%.5f, %.5f", latitude, longitude));
        try {
            getSharedPreferences("state", MODE_PRIVATE).edit().remove("error").apply();
            Intent intent = new Intent(this, MockLocationService.class);
            intent.setAction(MockLocationService.ACTION_START);
            intent.putExtra(MockLocationService.EXTRA_LAT, latitude);
            intent.putExtra(MockLocationService.EXTRA_LON, longitude);
            startForegroundService(intent);
            status.setText("GPS simulato");
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 52);
            }
        } catch (Exception ex) { message("Avvio non riuscito: " + ex.getMessage()); }
    }
    private void stopSimulation() {
        Intent intent = new Intent(this, MockLocationService.class);
        intent.setAction(MockLocationService.ACTION_STOP);
        try { startService(intent); status.setText("Pronto"); }
        catch (Exception ex) { message("Arresto non riuscito"); }
    }
    private void openDevSettings() {
        try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
        catch (Exception ex) { message("Apri Impostazioni → Opzioni sviluppatore"); }
    }
    @Override public void onRequestPermissionsResult(int req, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(req, permissions, grants);
        if (req == PERMISSIONS && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) startSimulation();
        else if (req == PERMISSIONS) message("Serve il permesso di localizzazione per avviare il servizio GPS");
    }
    @Override protected void onResume() {
        super.onResume();
        if (status != null) {
            android.content.SharedPreferences simulation = getSharedPreferences("state", MODE_PRIVATE);
            String error = simulation.getString("error", null);
            status.setText(error != null && !error.isEmpty() ? "Controlla GPS" :
                simulation.getBoolean("running", false) ? "GPS simulato" : "Pronto");
            if (error != null && !error.isEmpty()) {
                simulation.edit().remove("error").apply();
                message(error);
            }
        }
    }
    private void message(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }
    @Override protected void onDestroy() { worker.shutdownNow(); super.onDestroy(); }
}
